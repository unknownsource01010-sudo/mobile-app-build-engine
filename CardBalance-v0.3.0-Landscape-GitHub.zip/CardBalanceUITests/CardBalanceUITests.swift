import XCTest
import UIKit

final class CardBalanceUITests: XCTestCase {
    override func setUpWithError() throws { continueAfterFailure = false }
    func testLandscapeUsesFullScreenWidth() {
        XCUIDevice.shared.orientation = .landscapeLeft
        let app = XCUIApplication()
        app.launch()
        XCTAssertTrue(app.buttons["Add / Scan"].firstMatch.waitForExistence(timeout: 10))
        let window = app.windows.firstMatch.frame
        let screen = UIScreen.main.bounds
        XCTAssertGreaterThan(window.width, window.height)
        XCTAssertGreaterThanOrEqual(window.width, max(screen.width, screen.height) - 1,
                                    "App is letterboxed instead of using the entire landscape screen")
        let screenshot = XCTAttachment(screenshot: app.screenshot())
        screenshot.name = "CardBalance-landscape"
        screenshot.lifetime = .keepAlways
        add(screenshot)
    }
    func testManualCardEntryIsReachable() {
        XCUIDevice.shared.orientation = .landscapeRight
        let app = XCUIApplication()
        app.launch()
        let addButton = app.buttons["Add / Scan"].firstMatch
        XCTAssertTrue(addButton.waitForExistence(timeout: 10))
        addButton.tap()
        let manual = app.buttons["Add card manually"]
        XCTAssertTrue(manual.waitForExistence(timeout: 5))
        manual.tap()
        XCTAssertTrue(app.textFields["Full card number — confirm the scan"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["Save All"].exists)
    }
}
