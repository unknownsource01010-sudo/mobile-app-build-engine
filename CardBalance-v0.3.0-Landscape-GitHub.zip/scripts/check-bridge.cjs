const fs = require('fs');
const vm = require('vm');
const assert = require('node:assert/strict');
const path = require('path');
class Input {
  constructor(type, name, autocomplete = '') { this.type = type; this.name = name; this.id = ''; this.autocomplete = autocomplete; this.labels = []; this._value = ''; this.events = []; }
  get value() { return this._value; }
  set value(v) { this._value = v; }
  getClientRects() { return [1]; }
  getAttribute() { return null; }
  dispatchEvent(e) { this.events.push(e.type); }
}
let inputList = [];
const document = {body: {innerText:''}, documentElement:{}, querySelectorAll: () => inputList};
const context = {window:{}, document, location:{protocol:'https:',hostname:'www.lowes.com',href:'https://www.lowes.com/balance'},
  getComputedStyle: () => ({visibility:'visible'}), HTMLInputElement:Input, Event:class {constructor(type) {this.type=type;}},
  MutationObserver:class {observe(){}},setTimeout:() => {}};
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(__dirname,'../CardBalance/Resources/BalanceBridge.js'),'utf8'),context);
const bridge=context.window.CardBalanceBridge;
const extract=t => JSON.parse(JSON.stringify(bridge.extract(t)));
assert.equal(extract('Available balance: $1,234.56')[0].amount,'1234.56');
assert.equal(extract('Card balance\n$0.00')[0].amount,'0.00');
assert.equal(extract('Current balance: USD $25.75')[0].amount,'25.75');
assert.equal(extract('Transaction $50.00\nInitial value: $100.00').length,0);
assert.equal(extract('Check your gift card balance $25.00').length,0);
assert.equal(extract('Example: Balance $25.00').length,0);
assert.equal(extract('Balance $25.001').length,0);
assert.equal(extract('Balance $1,2345.00').length,0);
assert.equal(extract('Balance: USD 25.00')[0].amount,'25.00');
assert.equal(extract('Balance: £25.00').length,0);
assert.equal(extract('Remaining balance $15.25\nRemaining balance $15.25').length,1);
assert.equal(extract('Balance $15.25\nBalance $20.00').length,2);
const number=new Input('text','cardNumber'), pin=new Input('password','pin');
inputList=[number,pin];
bridge.fillCard({host:'attacker.test',cardNumber:'1111222233334444',pin:'1234'});
assert.equal(number.value,'');
bridge.fillCard({host:'www.lowes.com',cardNumber:'1111222233334444',pin:'1234'});
assert.equal(number.value,'1111222233334444'); assert.equal(pin.value,'1234');
const user=new Input('text','username','username'), password=new Input('password','password','current-password');
user.form=password.form={querySelectorAll:()=>[user,password],innerText:'Sign In'};
inputList=[user,password];
assert.equal(bridge.fillLogin({host:'attacker.test',username:'test',password:'secret'}),false);
assert.equal(password.value,'');
assert.equal(bridge.fillLogin({host:'www.lowes.com',username:'test',password:'secret'}),true);
assert.equal(user.value,'test');assert.equal(password.value,'secret');
assert.deepEqual(password.events,['input','change']);
console.log('Balance bridge regression checks passed (amounts, false positives, origin boundaries, card/login filling).');
