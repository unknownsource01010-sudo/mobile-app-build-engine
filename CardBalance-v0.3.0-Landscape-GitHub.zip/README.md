# CardBalance iPhone v0.3.0

Landscape card spreadsheet with on-device photo reading, full card numbers, and a balance-provider checker.

## What changed

- Added a modern launch screen to prevent legacy-size launch behavior. The spreadsheet and white background extend across landscape screen edges; the toolbar stays clear of the camera cutout.
- Excel-style column letters, row numbers, green header, alternating rows, search, sorting, separate totals per currency, and CSV export.
- Full card numbers are visible in column C. Hide Numbers conceals them; leaving the app also conceals them. Turn Full Numbers back on when returning.
- Full numbers, optional gift-card PIN/access numbers, and per-card/per-website username/password pairs are saved in the iPhone Keychain, accessible while unlocked and restricted to this device.
- Company/provider identification reads text and websites printed on the image. A Visa/Mastercard network logo is not enough to guess a provider. Unrecognized or conflicting companies require review.
- Balance Check opens a native in-app web checker. Standard sign-in forms trigger the native login popup; the Login button also opens it. Saved logins fill the same website for that card on later checks. You review and submit the provider's form.
- Read Balance finds clearly labeled USD balances on the displayed page. Confirm the amount and card before saving it to the sheet. If the site uses a different format, Enter Balance lets you record its displayed amount.
- Landscape camera capture, multiple Photos, multiple image Files, batch review and manual entry remain available. Front/back scans can be merged before saving.

## Companies included

MyPrepaidCenter, MyBalanceNow, PrepaidGiftBalance, MyGift / GiftCardMall, PrepaidCardStatus, Vanilla Gift, Lowe's, The Home Depot, Sheetz, Walmart, Target and Starbucks. Other providers can use an HTTPS address confirmed from the card.

The scanner prefers a recognized printed provider website over another store name. Check the provider in the review row, especially when a rebate/reward card was supplied by a store but is managed by another company.

Provider routes were checked against their sites or issuer references. This does **not** mean authenticated balance retrieval has been tested with real cards. The Home Depot may require account sign-in; the Sheetz service may show a separate gift-card checker or wallet. Provider verification steps, login form changes and third-party redirects can require your interaction.

Reference pages:
- https://www.visa.com/en-us/personal/cards/gift/gift-card-balance
- https://www.myprepaidcenter.com/
- https://www.prepaidcardstatus.com/
- https://www.lowes.com/l/help/gift-card-balance/
- https://www.homedepot.com/c/gift-cards
- https://www.sheetz.com/FAQ
- https://sheetz.thegiftcardshop.com/faq

## Use on iPhone

1. Tap Add / Scan and select photos, camera, Files, or manual entry.
2. Confirm the company, full number and checker address. Merge a back scan into the previous front scan if needed. Saving the full number is enabled by default and can be turned off for an individual scan.
3. Save All. Column C displays the full saved number; swipe horizontally to see the remaining columns.
4. Tap a row to edit. For a balance check, swipe to Actions → Check, or hold a row and choose Check Balance.
5. Use Card → Fill saved number / PIN, or Card → Show / copy Card Details if a site needs manual entry. Expiry and CVV/security codes requested by the provider are entered on its page; this app does not save those fields.
6. Enter your login in the native popup when needed. It is saved for this card and this exact website if Save Login is on. The app fills the form and you tap the provider's Sign In / Check button.
7. Once the provider shows this card's balance, tap Read Balance, select the correct amount, confirm This is the balance for this card, and Save to Sheet.

Login secrets never appear in CSV. CSV uses the last four digits; the full number remains available inside the app. Card images are discarded after review. Browser sessions are isolated and not retained between checks; saved credentials remain in Keychain. Copy buttons expire the local clipboard entry after 60 seconds.

## Existing cards

The bundle identifier and `cards.json` location are unchanged, and existing v0.2 rows decode without migration loss. Install as an update using the same signing identity to preserve the app container. **Do not uninstall the old app first.**

v0.2 stored only the last four digits, so existing rows need a rescan or manual full-number entry. Numbers cannot be reconstructed from their last four.

## Build the IPA on GitHub

This package is source code; it does not contain a newly compiled IPA.

1. Extract this ZIP into the CardBalance repository root. `project.yml`, `CardBalance/`, `CardBalanceTests/`, `CardBalanceUITests/` and `scripts/` must be at the root.
2. Replace the existing `.github/workflows/build-ios.yml` with the included file. The standalone `CardBalance-v0.3.0-build-ios.yml` is the same workflow; avoid keeping two active copies.
3. Commit to `main`, or run Actions → CardBalance Landscape IPA → Run workflow.
4. The workflow runs JavaScript, native regression and landscape UI tests, builds for iPhone, verifies launch-screen/orientation settings and the web-reader resource, and packages `CardBalance-v0.3.0-unsigned.ipa`.
5. Download `CardBalance-v0.3.0-unsigned-ipa` from the successful run. Artifacts are kept for one day to reduce quota use. An unsigned IPA needs signing with your existing sideloading method before installation.

The macOS runner needs Xcode and an available iPhone simulator. XcodeGen is installed by the workflow. No paid API, remote AI service, or backend account is required.

## Validation status

Locally executed: JavaScript balance extraction and origin/form-fill regression checks, Swift syntax parsing, asset JSON validation, YAML validation and shell-script syntax checks.

Not executed in the authoring environment: an Xcode type-check/build, the native XCTest suite, the simulator UI tests, installation on a physical iPhone, or authenticated lookups against real cards. The supplied macOS workflow performs the Xcode build and simulator tests. Actual provider sessions need verification on the installed build.
