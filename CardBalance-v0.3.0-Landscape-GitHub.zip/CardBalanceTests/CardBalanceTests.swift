import XCTest
@testable import CardBalance

final class CardBalanceTests: XCTestCase {
    func testExistingRowsDecodeWithoutNewFields() throws {
        let old = """
        [{"id":"5BA6C8E2-7851-4E1F-914B-8D11A4FB0693","issuer":"Lowe's","nickname":"Tools","last4":"0012","balance":25.5,"notes":"Keep"}]
        """
        let rows = try JSONDecoder().decode([CardRecord].self, from: Data(old.utf8))
        XCTAssertEqual(rows.count, 1)
        XCTAssertEqual(rows[0].last4, "0012")
        XCTAssertEqual(rows[0].currency, "USD")
        XCTAssertEqual(rows[0].balance, Decimal(string: "25.5"))
    }
    func testFullNumberAndIssuerReadFromPhotoText() {
        let result = CardScanner.analyze(lines: ["Lowe's", "1234 5678 9012 3456", "lowes.com"])
        XCTAssertEqual(result.issuer, "Lowe's")
        XCTAssertEqual(result.cardNumber, "1234567890123456")
        XCTAssertEqual(result.last4, "3456")
        XCTAssertTrue(result.officialURL.contains("lowes.com"))
    }
    func testProviderWebsiteWinsOverStoreMention() {
        let result = CardScanner.analyze(lines: ["Target", "Redeem at MyPrepaidCenter.com"])
        XCTAssertEqual(result.issuer, "MyPrepaidCenter")
    }
    func testNetworkLogoDoesNotGuessProvider() {
        XCTAssertTrue(CardScanner.analyze(lines: ["VISA", "Gift card"]).issuer.isEmpty)
        XCTAssertTrue(CardScanner.analyze(lines: ["MASTERCARD"]).officialURL.isEmpty)
    }
    func testAmbiguousBrandsNeedReview() {
        XCTAssertTrue(CardScanner.analyze(lines: ["Lowe's", "The Home Depot"]).issuer.isEmpty)
    }
    func testTelephoneAndDateNotReadAsCard() {
        let result = CardScanner.analyze(lines: ["1-800-560-7172", "12/28", "$50.00"])
        XCTAssertEqual(result.cardNumber, "")
    }
    func testLongRetailCardNumberIsPreserved() {
        let result = CardScanner.analyze(lines: ["1234567890123456789012345"])
        XCTAssertEqual(result.cardNumber, "1234567890123456789012345")
    }
    func testNamedCompaniesHaveSecureRoutes() {
        for name in ["MyPrepaidCenter", "Lowe's", "The Home Depot", "Sheetz"] {
            XCTAssertNotNil(IssuerDirectory.issuer(named: name).flatMap { IssuerDirectory.secureURL($0.url) })
        }
    }
    func testCredentialOriginBoundary() {
        XCTAssertTrue(IssuerDirectory.allows(host: "www.lowes.com", domains: ["lowes.com"]))
        XCTAssertFalse(IssuerDirectory.allows(host: "lowes.com.attacker.test", domains: ["lowes.com"]))
        XCTAssertFalse(IssuerDirectory.allows(host: "fakelowes.com", domains: ["lowes.com"]))
        XCTAssertNil(IssuerDirectory.secureURL("http://lowes.com"))
        XCTAssertNil(IssuerDirectory.secureURL("https://user:password@lowes.com"))
        XCTAssertNil(IssuerDirectory.secureURL("https://lowes.com:8080"))
    }
    func testAmountsAreExactDecimalsAndRejectGarbage() {
        XCTAssertEqual(AmountParser.parse("$1,234.56"), Decimal(string: "1234.56"))
        XCTAssertEqual(AmountParser.parse("0.00"), .zero)
        for invalid in ["12abc", "-1", "1.001", "1e4", "", "2026/10/03", "1,23", "$12$"] { XCTAssertNil(AmountParser.parse(invalid)) }
    }
    @MainActor func testCSVFormulaAndQuoteEscaping() {
        XCTAssertEqual(CardStore.csvCell("=HYPERLINK(\"x\")"), "\"'=HYPERLINK(\"\"x\"\")\"")
        XCTAssertEqual(CardStore.csvCell("  +1"), "\"'  +1\"")
        XCTAssertEqual(CardStore.csvCell("Notes, here"), "\"Notes, here\"")
    }
    func testSpreadsheetJSONDoesNotContainFullNumbersOrPasswords() throws {
        let card = CardRecord(issuer: "Lowe's", nickname: "Tools", last4: "3456", balance: nil, lastChecked: nil)
        let text = String(decoding: try JSONEncoder().encode(card), as: UTF8.self)
        XCTAssertFalse(text.contains("cardNumber"))
        XCTAssertFalse(text.contains("password"))
    }
}
