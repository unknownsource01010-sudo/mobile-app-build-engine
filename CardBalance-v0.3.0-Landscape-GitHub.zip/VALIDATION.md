# CardBalance v0.3.0 validation

Passed in this environment:
- JavaScript balance extraction, false-positive, origin-boundary and form-fill regression checks (Node).
- Syntax parsing of all 18 Swift source/test files.
- Project and workflow YAML, asset JSON, and embedded shell/Python syntax.
- Required modern launch screen, two landscape orientations, version and unchanged bundle identifier.
- ZIP integrity and inclusion of the separate web-reader resource and build workflow.

Pending on the supplied macOS workflow:
- Xcode type-checking, native unit tests and simulator UI tests.
- Unsigned iPhone device build and IPA packaging.

Pending on the installed iPhone:
- Camera permission/capture and real-device edge-to-edge layout.
- Live issuer sign-in and balance checks with your actual cards.

No new IPA has been compiled in this Linux authoring environment. The source ZIP contains no IPA and no claimed live balance results.
