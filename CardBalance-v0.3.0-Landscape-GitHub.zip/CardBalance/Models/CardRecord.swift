import Foundation

struct CardRecord: Identifiable, Codable, Equatable {
    var id = UUID()
    var issuer: String
    var nickname: String
    var last4: String
    var balance: Decimal?
    var lastChecked: Date?
    var notes: String = ""
    var officialBalanceURL: String?
    // Optional additions preserve v0.2 JSON decoding and existing rows.
    var currencyCode: String?
    var balanceSource: String?
    var balancePageURL: String?
    var balanceEvidence: String?
    var currency: String { currencyCode ?? "USD" }
    var maskedInfo: String { last4.isEmpty ? nickname : "\(nickname) •••• \(last4)" }
    var money: String {
        guard let balance else { return "—" }
        let f = NumberFormatter()
        f.numberStyle = .currency; f.currencyCode = currency
        return f.string(from: balance as NSDecimalNumber) ?? "\(balance) \(currency)"
    }
}

enum AmountParser {
    static func parse(_ text: String) -> Decimal? {
        var clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if clean.hasPrefix("$") { clean.removeFirst(); clean = clean.trimmingCharacters(in: .whitespacesAndNewlines) }
        guard clean.range(of: #"^(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d{1,2})?$"#, options: .regularExpression) != nil else { return nil }
        return Decimal(string: clean.replacingOccurrences(of: ",", with: ""), locale: Locale(identifier: "en_US_POSIX"))
    }
}
