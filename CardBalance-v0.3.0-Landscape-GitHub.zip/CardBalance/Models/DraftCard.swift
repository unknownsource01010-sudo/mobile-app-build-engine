import Foundation
struct DraftCard: Identifiable {
    let id = UUID()
    var issuer = ""
    var nickname = ""
    var last4 = ""
    var balance = ""
    var notes = ""
    var sourceLabel = ""
    var rawText = ""
    var officialURL = ""
    var cardNumber = ""
    var pin = ""
    var rememberCard = false
}
