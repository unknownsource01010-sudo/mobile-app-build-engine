import Foundation
import Combine

@MainActor final class CardStore: ObservableObject {
    @Published private(set) var cards: [CardRecord] = []
    @Published var errorMessage: String?
    private let url: URL
    private var canWrite = true
    init() {
        let directory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        url = directory.appendingPathComponent("cards.json")
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: url.path) {
                cards = try JSONDecoder().decode([CardRecord].self, from: Data(contentsOf: url))
            }
        } catch { canWrite = false; errorMessage = "Your saved sheet could not be opened. \(error.localizedDescription)" }
    }
    @discardableResult func add(_ card: CardRecord) -> Bool { persist(cards + [card]) }
    @discardableResult func update(_ card: CardRecord) -> Bool {
        var next = cards
        guard let index = next.firstIndex(where: { $0.id == card.id }) else { return false }
        next[index] = card
        return persist(next)
    }
    func delete(id: UUID) {
        if persist(cards.filter { $0.id != id }) {
            do { try SecureCardVault.deleteCard(id) }
            catch { errorMessage = "Row removed; its saved login could not be erased. \(error.localizedDescription)" }
        }
    }
    @discardableResult private func persist(_ next: [CardRecord]) -> Bool {
        guard canWrite else { errorMessage = "Your existing sheet could not be read. It has been preserved; no changes were written."; return false }
        do {
            try JSONEncoder().encode(next).write(to: url, options: [.atomic, .completeFileProtection])
            cards = next
            return true
        } catch { errorMessage = "Your change was not saved. \(error.localizedDescription)"; return false }
    }
    func csv() -> String {
        var rows = ["Company,Card,Last 4,Balance,Currency,Last Checked,Source,Notes"]
        let f = ISO8601DateFormatter()
        for c in cards {
            let values = [c.issuer, c.nickname, c.last4,
                          c.balance.map { NSDecimalNumber(decimal: $0).stringValue } ?? "", c.currency,
                          c.lastChecked.map { f.string(from: $0) } ?? "", c.balanceSource ?? "Saved", c.notes]
            rows.append(values.map(Self.csvCell).joined(separator: ","))
        }
        return "\u{FEFF}" + rows.joined(separator: "\r\n")
    }
    static func csvCell(_ text: String) -> String {
        let first = text.trimmingCharacters(in: .whitespacesAndNewlines).first
        let safe = first.map { "=+-@".contains($0) } == true ? "'" + text : text
        return "\"" + safe.replacingOccurrences(of: "\"", with: "\"\"") + "\""
    }
}
