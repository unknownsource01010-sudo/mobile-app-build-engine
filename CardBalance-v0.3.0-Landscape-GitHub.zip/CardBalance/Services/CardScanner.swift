import Vision
import UIKit
import ImageIO

struct ScanResult {
    var rawText: String
    var last4: String
    var cardNumber: String
    var issuer: String
    var officialURL: String
}
enum CardScanner {
    static func scan(_ image: UIImage) async throws -> ScanResult {
        guard let cg = image.cgImage else { throw NSError(domain: "CardScanner", code: 1) }
        let orientation = cgOrientation(image.imageOrientation)
        return try await withCheckedThrowingContinuation { continuation in
            DispatchQueue.global(qos: .userInitiated).async {
                do {
                    let request = VNRecognizeTextRequest()
                    request.recognitionLevel = .accurate; request.usesLanguageCorrection = false
                    try VNImageRequestHandler(cgImage: cg, orientation: orientation).perform([request])
                    let lines = request.results?.compactMap { $0.topCandidates(1).first?.string } ?? []
                    continuation.resume(returning: analyze(lines: lines))
                } catch { continuation.resume(throwing: error) }
            }
        }
    }
    static func analyze(lines: [String]) -> ScanResult {
        let raw = lines.joined(separator: "\n")
        let expression = try? NSRegularExpression(pattern: #"(?<!\d)(?:\d[ -]?){12,30}(?!\d)"#)
        let numbers = lines.flatMap { line -> [String] in
            return (expression?.matches(in: line, range: NSRange(line.startIndex..., in: line)) ?? []).compactMap { match in
                guard let r = Range(match.range, in: line) else { return nil }
                let value = line[r].filter(\.isNumber)
                return (12...30).contains(value.count) ? value : nil
            }
        }
        let number = numbers.first ?? ""
        let candidates = IssuerDirectory.matches(in: raw)
        let match = candidates.count == 1 ? candidates[0] : nil
        return ScanResult(rawText: raw, last4: String(number.suffix(4)), cardNumber: number,
                          issuer: match?.name ?? "", officialURL: match?.url ?? printedURL(in: raw))
    }
    private static func printedURL(in text: String) -> String {
        guard let detector = try? NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue) else { return "" }
        for match in detector.matches(in: text, range: NSRange(text.startIndex..., in: text)) {
            guard let u = match.url, var p = URLComponents(url: u, resolvingAgainstBaseURL: false),
                  p.scheme == "http" || p.scheme == "https" else { continue }
            p.scheme = "https"; p.query = nil; p.fragment = nil
            if let value = p.url?.absoluteString, IssuerDirectory.secureURL(value) != nil { return value }
        }
        return ""
    }
    private static func cgOrientation(_ value: UIImage.Orientation) -> CGImagePropertyOrientation {
        switch value {
        case .up: return .up
        case .down: return .down
        case .left: return .left
        case .right: return .right
        case .upMirrored: return .upMirrored
        case .downMirrored: return .downMirrored
        case .leftMirrored: return .leftMirrored
        case .rightMirrored: return .rightMirrored
        @unknown default: return .up
        }
    }
}
