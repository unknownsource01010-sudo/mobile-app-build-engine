import Foundation

struct Issuer: Identifiable {
    let id: String
    let name: String
    let aliases: [String]
    let url: String
    let domains: [String]
    let instructions: String
}

enum IssuerDirectory {
    // Match the actual card provider/brand, never a payment-network logo alone.
    static let all: [Issuer] = [
        Issuer(id: "myprepaidcenter", name: "MyPrepaidCenter",
               aliases: ["myprepaidcenter", "my prepaid center", "my prepaid card center", "myprepaidcenter.com"],
               url: "https://www.myprepaidcenter.com/", domains: ["myprepaidcenter.com"],
               instructions: "Choose your card/sign-in option and open its balance details."),
        Issuer(id: "mybalancenow", name: "MyBalanceNow",
               aliases: ["mybalancenow", "my balance now", "mybalancenow.com"],
               url: "https://www.mybalancenow.com/", domains: ["mybalancenow.com"],
               instructions: "Enter the card details requested by the provider."),
        Issuer(id: "prepaidgiftbalance", name: "PrepaidGiftBalance",
               aliases: ["prepaidgiftbalance", "prepaid gift balance", "prepaidgiftbalance.com"],
               url: "https://www.prepaidgiftbalance.com/", domains: ["prepaidgiftbalance.com"],
               instructions: "Use the provider printed on this card; complete any required verification."),
        Issuer(id: "mygift", name: "MyGift / GiftCardMall",
               aliases: ["giftcardmall", "gift card mall", "mygift.giftcardmall.com", "giftcardmall.com/mygift"],
               url: "https://mygift.giftcardmall.com/", domains: ["giftcardmall.com"],
               instructions: "Use the MyGift service shown on the back of your card."),
        Issuer(id: "prepaidcardstatus", name: "PrepaidCardStatus",
               aliases: ["prepaidcardstatus", "prepaid card status", "prepaidcardstatus.com"],
               url: "https://www.prepaidcardstatus.com/", domains: ["prepaidcardstatus.com"],
               instructions: "Sign in with the card number and security code, or choose your wallet login."),
        Issuer(id: "vanilla", name: "Vanilla Gift",
               aliases: ["vanilla gift", "vanillagift.com", "vanillagift"],
               url: "https://balance.vanillagift.com/", domains: ["vanillagift.com"],
               instructions: "Enter this card's details, then choose Check Balance."),
        Issuer(id: "lowes", name: "Lowe's", aliases: ["lowe's", "lowe’s", "lowes", "lowes.com"],
               url: "https://www.lowes.com/l/help/gift-card-balance/", domains: ["lowes.com"],
               instructions: "Use your gift card number and PIN in the balance checker."),
        Issuer(id: "homedepot", name: "The Home Depot", aliases: ["home depot", "homedepot.com"],
               url: "https://www.homedepot.com/c/gift-cards", domains: ["homedepot.com"],
               instructions: "Choose Check Balance. Home Depot may require an account sign-in."),
        Issuer(id: "sheetz", name: "Sheetz", aliases: ["sheetz", "sheetz.com", "sheetz.myretailcard.com"],
               url: "https://sheetz.myretailcard.com/", domains: ["sheetz.com", "sheetz.myretailcard.com"],
               instructions: "Use the gift-card checker. Your Sheetz account also shows cards in My Wallet."),
        Issuer(id: "walmart", name: "Walmart", aliases: ["walmart", "wal-mart", "walmart.com"],
               url: "https://www.walmart.com/account/giftcards/balance", domains: ["walmart.com"],
               instructions: "Enter the Walmart gift card number and PIN."),
        Issuer(id: "target", name: "Target", aliases: ["target", "target.com"],
               url: "https://www.target.com/guest/gift-card-balance", domains: ["target.com"],
               instructions: "Enter your card number and access number, then check the balance."),
        Issuer(id: "starbucks", name: "Starbucks", aliases: ["starbucks", "starbucks.com"],
               url: "https://www.starbucks.com/gift", domains: ["starbucks.com"],
               instructions: "Open your gift card/account and view its current balance.")
    ]
    static func matches(in text: String) -> [Issuer] {
        let lower = text.lowercased()
        let domainMatches = all.filter { issuer in
            issuer.domains.contains { domain in
                lower.range(of: "(?<![a-z0-9.-])(?:[a-z0-9-]+\\.)*" + NSRegularExpression.escapedPattern(for: domain) + "(?![a-z0-9.-])", options: .regularExpression) != nil
            }
        }
        if domainMatches.count == 1 { return domainMatches }
        return all.filter { issuer in
            issuer.aliases.contains { alias in
                let escaped = NSRegularExpression.escapedPattern(for: alias)
                return lower.range(of: "(?<![a-z0-9])" + escaped + "(?![a-z0-9])", options: .regularExpression) != nil
            }
        }
    }
    static func issuer(named name: String) -> Issuer? {
        let name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        return all.first { $0.name.caseInsensitiveCompare(name) == .orderedSame }
    }
    static func secureURL(_ text: String) -> URL? {
        let value = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let u = URL(string: value), u.scheme?.lowercased() == "https", let host = u.host,
              host.contains("."), u.user == nil, u.password == nil, u.port == nil || u.port == 443 else { return nil }
        return u
    }
    static func allows(host: String, domains: [String]) -> Bool {
        let value = host.lowercased()
        return domains.contains { value == $0.lowercased() || value.hasSuffix("." + $0.lowercased()) }
    }
    static func domains(for card: CardRecord, url: URL) -> [String] {
        if let issuer = issuer(named: card.issuer), let host = url.host, allows(host: host, domains: issuer.domains) {
            return issuer.domains
        }
        return [url.host?.lowercased() ?? ""]
    }
}
