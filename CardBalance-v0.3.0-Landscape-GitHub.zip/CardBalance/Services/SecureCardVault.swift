import Foundation
import Security

struct CardSecrets: Codable { var cardNumber = ""; var pin = "" }
struct SavedLogin: Codable { var username: String; var password: String }

enum SecureCardVault {
    private static let service = "com.sidekick.cardbalance.vault"
    static func put<T: Encodable>(_ value: T, card: UUID, name: String) throws {
        let data = try JSONEncoder().encode(value)
        let query = key(card, name)
        let status = SecItemUpdate(query as CFDictionary, [kSecValueData as String: data] as CFDictionary)
        if status == errSecItemNotFound {
            var item = query
            item[kSecValueData as String] = data
            item[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
            let result = SecItemAdd(item as CFDictionary, nil)
            guard result == errSecSuccess else { throw failure(result) }
        } else if status != errSecSuccess { throw failure(status) }
    }
    static func get<T: Decodable>(_ type: T.Type, card: UUID, name: String) throws -> T? {
        var query = key(card, name)
        query[kSecReturnData as String] = true; query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = result as? Data else { throw failure(status) }
        return try JSONDecoder().decode(type, from: data)
    }
    static func remove(card: UUID, name: String) throws {
        let status = SecItemDelete(key(card, name) as CFDictionary)
        if status != errSecSuccess && status != errSecItemNotFound { throw failure(status) }
    }
    static func deleteCard(_ card: UUID) throws { try removeMatching(prefix: card.uuidString + ":") }
    static func deleteLogins(_ card: UUID) throws { try removeMatching(prefix: card.uuidString + ":login:") }
    private static func removeMatching(prefix: String) throws {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                  kSecAttrService as String: service, kSecReturnAttributes as String: true,
                                  kSecMatchLimit as String: kSecMatchLimitAll]
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        if status == errSecItemNotFound { return }
        guard status == errSecSuccess else { throw failure(status) }
        for item in result as? [[String: Any]] ?? [] {
            if let account = item[kSecAttrAccount as String] as? String,
               account.hasPrefix(prefix) {
                let delete: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                            kSecAttrService as String: service, kSecAttrAccount as String: account]
                let value = SecItemDelete(delete as CFDictionary)
                if value != errSecSuccess && value != errSecItemNotFound { throw failure(value) }
            }
        }
    }
    private static func key(_ card: UUID, _ name: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service,
         kSecAttrAccount as String: card.uuidString + ":" + name]
    }
    private static func failure(_ status: OSStatus) -> NSError {
        NSError(domain: NSOSStatusErrorDomain, code: Int(status), userInfo: [NSLocalizedDescriptionKey:
            (SecCopyErrorMessageString(status, nil) as String?) ?? "Secure storage is unavailable."])
    }
}
