import Foundation
import WebKit
import UIKit
import Combine

struct LoginPrompt: Identifiable { var id: String { host }; let host: String }
struct BalanceCandidate: Identifiable {
    let id = UUID()
    let amount: Decimal
    let currency: String
    let evidence: String
    let pageURL: String
    var display: String {
        let f = NumberFormatter(); f.numberStyle = .currency; f.currencyCode = currency
        return f.string(from: amount as NSDecimalNumber) ?? "\(amount)"
    }
}
@MainActor private final class WeakBalanceHandler: NSObject, WKScriptMessageHandler {
    weak var owner: BalanceWebSession?
    init(_ owner: BalanceWebSession) { self.owner = owner }
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        owner?.userContentController(controller, didReceive: message)
    }
}

@MainActor final class BalanceWebSession: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
    @Published var loginPrompt: LoginPrompt?
    @Published var candidates: [BalanceCandidate] = []
    @Published var host = ""
    @Published var status = ""
    @Published var loading = false
    @Published var showRedirect = false
    @Published var pendingURL: URL? { didSet { showRedirect = pendingURL != nil } }
    @Published var showBalances = false
    private var card: CardRecord
    private var allowedDomains: [String] = []
    private var filledLoginPages: Set<String> = []
    private var dismissedLoginHosts: Set<String> = []
    private var busyLogin = false
    private(set) var started = false

    lazy var webView: WKWebView = {
        let config = WKWebViewConfiguration()
        // Isolated per-card web session. Credentials persist only in Keychain.
        config.websiteDataStore = .nonPersistent()
        let controller = WKUserContentController()
        controller.add(WeakBalanceHandler(self), name: "cardBalance")
        if let path = Bundle.main.url(forResource: "BalanceBridge", withExtension: "js"),
           let script = try? String(contentsOf: path) {
            controller.addUserScript(WKUserScript(source: script, injectionTime: .atDocumentEnd, forMainFrameOnly: true))
        }
        config.userContentController = controller
        let view = WKWebView(frame: .zero, configuration: config)
        view.navigationDelegate = self; view.uiDelegate = self
        view.scrollView.contentInsetAdjustmentBehavior = .never
        view.isOpaque = false; view.backgroundColor = .white
        return view
    }()

    init(card: CardRecord) { self.card = card; super.init() }
    func start(_ url: URL, company: String) {
        card.issuer = company
        allowedDomains = IssuerDirectory.domains(for: card, url: url)
        started = true; loading = true; host = url.host ?? ""
        webView.load(URLRequest(url: url))
    }
    func stop() {
        webView.stopLoading()
        webView.configuration.userContentController.removeScriptMessageHandler(forName: "cardBalance")
        webView.navigationDelegate = nil; webView.uiDelegate = nil
    }
    func approveRedirect() {
        guard let url = pendingURL, let host = url.host else { return }
        allowedDomains.append(host.lowercased()); pendingURL = nil
        webView.load(URLRequest(url: url))
    }
    private func permitted(_ url: URL?) -> Bool {
        guard let url, url.scheme?.lowercased() == "https", let host = url.host,
              url.user == nil, url.password == nil, url.port == nil || url.port == 443 else { return false }
        return IssuerDirectory.allows(host: host, domains: allowedDomains)
    }
    func requestLogin() {
        guard let url = webView.url, permitted(url), let host = url.host else { status = "Open the provider website first."; return }
        loginPrompt = LoginPrompt(host: host)
    }
    func cancelLogin(_ host: String) { dismissedLoginHosts.insert(host); loginPrompt = nil }
    func fillLogin(_ login: SavedLogin, host: String, remember: Bool) {
        guard webView.url?.host == host, permitted(webView.url) else { status = "The website changed. Open Login again."; loginPrompt = nil; return }
        do {
            if remember { try SecureCardVault.put(login, card: card.id, name: "login:" + host) }
            else { try SecureCardVault.remove(card: card.id, name: "login:" + host) }
            loginPrompt = nil
            injectLogin(login, host: host)
        } catch { status = "Login was not saved: \(error.localizedDescription)" }
    }
    private func injectLogin(_ login: SavedLogin, host: String) {
        guard let page = webView.url?.absoluteString else { return }
        let data = ["host": host, "username": login.username, "password": login.password]
        guard let literal = Self.literal(data) else { return }
        filledLoginPages.insert(page)
        webView.evaluateJavaScript("window.CardBalanceBridge?.fillLogin(\(literal))") { [weak self] value, error in
            guard let self else { return }
            self.status = (value as? Bool) == true && error == nil ? "Login filled. Review it and tap the website's Sign In." : "This form needs manual entry. Your saved login is available from Login."
        }
    }
    func fillCard() {
        guard permitted(webView.url), let host = webView.url?.host else { return }
        do {
            guard let details = try SecureCardVault.get(CardSecrets.self, card: card.id, name: "details"), !details.cardNumber.isEmpty else {
                status = "No full number saved. Edit or rescan this card first."; return
            }
            guard let literal = Self.literal(["host": host, "cardNumber": details.cardNumber, "pin": details.pin]) else { return }
            webView.evaluateJavaScript("window.CardBalanceBridge?.fillCard(\(literal))") { [weak self] value, error in
                let result = value as? [String: Any]
                self?.status = result?["number"] as? Bool == true && error == nil ? "Card details filled. Review them before submitting." : "This site uses different fields. Use Card Details to copy your number."
            }
        } catch { status = "Could not open secure details: \(error.localizedDescription)" }
    }
    func readBalance() {
        guard permitted(webView.url), let url = webView.url?.absoluteString else { return }
        webView.evaluateJavaScript("window.CardBalanceBridge?.readBalances()") { [weak self] result, error in
            guard let self, self.webView.url?.absoluteString == url else { return }
            if error != nil { self.status = "This page could not be read. Enter the balance shown by the provider."; return }
            self.accept(result as? [[String: Any]] ?? [], page: url)
            if !self.candidates.isEmpty { self.showBalances = true }
            else { self.status = "No clearly labeled USD balance found. Open this card's details, or enter its displayed balance manually." }
        }
    }
    private func accept(_ values: [[String: Any]], page: String) {
        candidates = values.compactMap { value in
            guard let amount = value["amount"] as? String, let parsed = AmountParser.parse(amount),
                  value["currency"] as? String == "USD", let evidence = value["evidence"] as? String else { return nil }
            return BalanceCandidate(amount: parsed, currency: "USD", evidence: String(evidence.prefix(200)), pageURL: page)
        }
        if !candidates.isEmpty { status = "Balance found. Tap Read Balance to verify and save it." }
    }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame, permitted(message.frameInfo.request.url), permitted(webView.url),
              let body = message.body as? [String: Any], let url = body["url"] as? String,
              url == webView.url?.absoluteString, let host = body["host"] as? String, host == webView.url?.host else { return }
        if body["kind"] as? String == "balances" {
            accept(body["candidates"] as? [[String: Any]] ?? [], page: url)
        } else if body["kind"] as? String == "login", !filledLoginPages.contains(url), !dismissedLoginHosts.contains(host), loginPrompt == nil, !busyLogin {
            busyLogin = true
            defer { busyLogin = false }
            do {
                if let saved = try SecureCardVault.get(SavedLogin.self, card: card.id, name: "login:" + host) { injectLogin(saved, host: host) }
                else { loginPrompt = LoginPrompt(host: host) }
            } catch { status = "Could not open saved login: \(error.localizedDescription)" }
        }
    }
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url else { decisionHandler(.cancel); return }
        if url.absoluteString == "about:blank" { decisionHandler(.allow); return }
        guard url.scheme?.lowercased() == "https", url.user == nil, url.password == nil, url.port == nil || url.port == 443 else {
            if action.targetFrame?.isMainFrame != false { status = "This checker only opens secure HTTPS pages." }
            decisionHandler(.cancel); return
        }
        if action.targetFrame?.isMainFrame == false { decisionHandler(.allow); return }
        if permitted(url) { decisionHandler(.allow) }
        else { pendingURL = url; status = "The provider wants to open another website. Confirm it to continue."; decisionHandler(.cancel) }
    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        filledLoginPages.removeAll()
        loading = true; candidates = []; host = webView.url?.host ?? host
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        loading = false; host = webView.url?.host ?? host
        status = "Open the balance for \(card.maskedInfo), then tap Read Balance."
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { failed(error) }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { failed(error) }
    private func failed(_ error: Error) {
        loading = false
        if (error as NSError).code != NSURLErrorCancelled { status = "Website could not load: \(error.localizedDescription)" }
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if action.targetFrame == nil, let url = action.request.url {
            if permitted(url) { webView.load(action.request) } else if IssuerDirectory.secureURL(url.absoluteString) != nil { pendingURL = url }
        }
        return nil
    }
    private static func literal(_ value: [String: String]) -> String? {
        guard let data = try? JSONSerialization.data(withJSONObject: value) else { return nil }
        return String(data: data, encoding: .utf8)
    }
}
