import SwiftUI
@main struct CardBalanceApp: App {
 @StateObject private var store=CardStore()
 var body: some Scene { WindowGroup { ContentView().environmentObject(store) } }
}
