(() => {
  'use strict';
  if (window.CardBalanceBridge) return;
  const visible = e => e && e.getClientRects().length && getComputedStyle(e).visibility !== 'hidden';
  const meta = e => [e.name, e.id, e.autocomplete, e.placeholder, e.getAttribute('aria-label'),
    ...Array.from(e.labels || []).map(x => x.textContent)].filter(Boolean).join(' ').toLowerCase();
  const inputs = () => Array.from(document.querySelectorAll('input')).filter(visible);
  function passwordField() {
    return inputs().find(e => {
      if (e.type !== 'password' || e.autocomplete === 'new-password') return false;
      if (/(?:\bpin\b|access.?number|security.?code|cvv|cvc|card.?number)/i.test(meta(e))) return false;
      return e.autocomplete === 'current-password' || /sign\s*in|log\s*in|login/i.test((e.form || e.parentElement).innerText || '');
    });
  }
  function setValue(e, value) {
    if (!e || !value) return false;
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    setter.call(e, value);
    e.dispatchEvent(new Event('input', {bubbles:true}));
    e.dispatchEvent(new Event('change', {bubbles:true}));
    return true;
  }
  function fillLogin(data) {
    if (location.protocol !== 'https:' || location.hostname !== data.host) return false;
    const p = passwordField();
    if (!p) return false;
    const root = p.form || document;
    const users = Array.from(root.querySelectorAll('input')).filter(visible);
    const u = users.find(e => e.autocomplete === 'username') || users.find(e =>
      e.type !== 'password' && /username|user.?name|email/i.test(meta(e)) && !/card|pin|search|newsletter/i.test(meta(e)));
    if (u && data.username) setValue(u, data.username);
    setValue(p, data.password);
    // Let the user review and press the actual provider's sign-in button.
    return true;
  }
  function fillCard(data) {
    if (location.protocol !== 'https:' || location.hostname !== data.host) return {number:false,pin:false};
    const eligible = inputs().filter(e => !e.disabled && !e.readOnly && !/search|newsletter|email|username|cvv|cvc/i.test(meta(e)));
    const number = eligible.find(e => /card.?number|gift.?card.?number|account.?number|cardnumber/i.test(meta(e)) && !/credit/i.test(meta(e)));
    const pin = eligible.find(e => /\bpin\b|access.?number|access.?code/i.test(meta(e)));
    return {number:setValue(number, data.cardNumber), pin:setValue(pin, data.pin)};
  }
  function extract(text) {
    const candidates = [];
    const regex = /\b(?:(?:available|remaining|current|gift\s*card|card)\s+)?balance\s*[:\-]?\s*(?:USD\s*\$?|\$)\s*((?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d{2})?)(?![\d.,])/gi;
    let match;
    while ((match = regex.exec(text)) && candidates.length < 15) {
      const before = text.slice(Math.max(0, match.index - 25), match.index);
      if (/check(?:\s+your)?\s*(?:gift\s*card\s*)?$/i.test(before) || /example\s*[:\-]?\s*$/i.test(before)) continue;
      const amount = match[1].replace(/,/g, '');
      if (candidates.some(c => c.amount === amount)) continue;
      const evidence = text.slice(Math.max(0, match.index - 45), Math.min(text.length, regex.lastIndex + 55)).trim();
      candidates.push({amount, currency:'USD', evidence});
    }
    return candidates;
  }
  const readBalances = () => extract((document.body?.innerText || '').slice(0, 200000));
  function post(value) {
    if (window.webkit?.messageHandlers?.cardBalance) window.webkit.messageHandlers.cardBalance.postMessage(value);
  }
  let queued = false, lastLoginURL = '', lastBalance = '';
  function inspect() {
    queued = false;
    if (location.protocol !== 'https:') return;
    if (passwordField() && lastLoginURL !== location.href) {
      lastLoginURL = location.href;
      post({kind:'login', host:location.hostname, url:location.href});
    }
    const candidates = readBalances();
    const key = JSON.stringify(candidates);
    if (candidates.length && lastBalance !== key) {
      lastBalance = key;
      post({kind:'balances', host:location.hostname, url:location.href, candidates});
    }
  }
  const queue = () => { if (!queued) { queued = true; setTimeout(inspect, 500); } };
  window.CardBalanceBridge = {fillLogin, fillCard, readBalances, extract};
  new MutationObserver(queue).observe(document.documentElement, {childList:true,subtree:true,characterData:true});
  queue();
})();
