import SwiftUI
import WebKit
import UIKit

struct BalanceCheckView: View {
    let card: CardRecord
    @EnvironmentObject var store: CardStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var session: BalanceWebSession
    @State private var company: String
    @State private var urlText: String
    @State private var opened = false
    @State private var showDetails = false

    init(card: CardRecord) {
        self.card = card
        _session = StateObject(wrappedValue: BalanceWebSession(card: card))
        _company = State(initialValue: card.issuer)
        _urlText = State(initialValue: card.officialBalanceURL ?? IssuerDirectory.issuer(named: card.issuer)?.url ?? "")
    }
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 14) {
                Button("Done") { session.stop(); dismiss() }
                VStack(alignment: .leading, spacing: 2) {
                    Text(card.maskedInfo).font(.headline).lineLimit(1)
                    Label(session.host.isEmpty ? "Choose balance provider" : session.host, systemImage: "lock.fill").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                if opened {
                    Button { session.webView.goBack() } label: { Image(systemName: "chevron.left") }.accessibilityLabel("Back")
                    Button { session.webView.reload() } label: { Image(systemName: "arrow.clockwise") }.accessibilityLabel("Reload")
                    Menu("Card") {
                        Button("Fill saved number / PIN") { session.fillCard() }
                        Button("Show / copy Card Details") { showDetails = true }
                        Button("Change balance provider") { opened = false }
                    }
                    Button("Login") { session.requestLogin() }
                    Button("Read Balance") { session.readBalance() }.buttonStyle(.borderedProminent).tint(.green)
                    Button("Enter Balance") { session.showBalances = true }
                }
            }.font(.subheadline).padding(.horizontal, 20).padding(.vertical, 8).background(Color(.systemGray6))
            if session.loading { ProgressView().progressViewStyle(.linear) }
            if opened {
                BalanceWebView(session: session)
                Text(session.status).font(.caption).frame(maxWidth: .infinity, alignment: .leading).padding(8).background(Color(.systemGray6))
            } else {
                Form {
                    Section("Company / balance provider") {
                        TextField("Company", text: $company)
                        ProviderPicker(issuer: $company, url: $urlText)
                        TextField("https://website printed on your card", text: $urlText).keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                        if let provider = IssuerDirectory.issuer(named: company) { Text(provider.instructions).font(.footnote) }
                    }
                    Section {
                        Text("Check the company and address printed on this card. A Visa or Mastercard logo alone cannot identify its balance provider.").font(.footnote)
                        Button("Open Balance Checker") { open() }.disabled(IssuerDirectory.secureURL(urlText) == nil)
                        if !session.status.isEmpty { Text(session.status).foregroundStyle(.secondary) }
                    }
                }
            }
        }
        .background(Color.white.ignoresSafeArea())
        .preferredColorScheme(.light)
        .statusBarHidden(true)
        .onAppear {
            if !opened, IssuerDirectory.secureURL(urlText) != nil { open() }
        }
        .sheet(item: $session.loginPrompt, onDismiss: { session.loginPrompt = nil }) { prompt in
            SavedLoginView(card: card, host: prompt.host,
                           save: { login, remember in session.fillLogin(login, host: prompt.host, remember: remember) },
                           cancel: { session.cancelLogin(prompt.host) })
        }
        .sheet(isPresented: $showDetails) { CardDetailsView(card: card) }
        .sheet(isPresented: $session.showBalances) {
            BalanceReviewView(card: card, candidates: session.candidates, currentURL: session.webView.url?.absoluteString,
                              saved: { session.status = "Confirmed balance saved to the spreadsheet." }).environmentObject(store)
        }
        .alert("Open another provider website?", isPresented: $session.showRedirect) {
            Button("Open") { session.approveRedirect() }
            Button("Cancel", role: .cancel) { session.pendingURL = nil }
        } message: {
            Text("The checker wants to continue at \(session.pendingURL?.host ?? ""). Only approve an address you recognize as the card provider or its sign-in service.")
        }
    }
    private func open() {
        guard let url = IssuerDirectory.secureURL(urlText) else { return }
        if var current = store.cards.first(where: { $0.id == card.id }) {
            current.issuer = company
            current.officialBalanceURL = url.absoluteString
            guard store.update(current) else { session.status = store.errorMessage ?? "Could not save provider."; return }
        }
        session.start(url, company: company); opened = true
    }
}
struct BalanceWebView: UIViewRepresentable {
    @ObservedObject var session: BalanceWebSession
    func makeUIView(context: Context) -> WKWebView { session.webView }
    func updateUIView(_ webView: WKWebView, context: Context) {}
}

struct SavedLoginView: View {
    let card: CardRecord
    let host: String
    let save: (SavedLogin, Bool) -> Void
    let cancel: () -> Void
    @State private var username = ""
    @State private var password = ""
    @State private var remember = true
    @State private var error: String?
    var body: some View {
        NavigationStack {
            Form {
                Section("Login for \(card.nickname)") {
                    Label(host, systemImage: "lock.fill").font(.headline)
                    TextField("Username / email", text: $username).textContentType(.username).textInputAutocapitalization(.never).autocorrectionDisabled()
                    SecureField("Password", text: $password).textContentType(.password)
                    Toggle("Save login for this card", isOn: $remember)
                    Text("Saved in this iPhone's Keychain for this card and this website. Review the filled form and tap Sign In on the provider's page.").font(.caption).foregroundStyle(.secondary)
                    Text("If the provider only wants a card number and PIN, cancel and use Card → Fill saved number / PIN.").font(.caption)
                }
                if let error { Text(error).foregroundStyle(.red) }
            }
            .navigationTitle("Card Login")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { cancel() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Fill Login") { save(SavedLogin(username: username, password: password), remember) }.disabled(password.isEmpty)
                }
            }
            .onAppear {
                do {
                    if let login = try SecureCardVault.get(SavedLogin.self, card: card.id, name: "login:" + host) { username = login.username; password = login.password }
                } catch { self.error = error.localizedDescription }
            }
        }.interactiveDismissDisabled()
    }
}

struct CardDetailsView: View {
    let card: CardRecord
    @Environment(\.dismiss) private var dismiss
    @State private var details = CardSecrets()
    @State private var showPIN = false
    @State private var error: String?
    var body: some View {
        NavigationStack {
            Form {
                Section(card.maskedInfo) {
                    Text(details.cardNumber.isEmpty ? "No full number saved. Edit or rescan this card." : details.cardNumber)
                        .font(.system(.body, design: .monospaced)).textSelection(.enabled)
                    Button("Copy card number for 60 seconds") { copy(details.cardNumber) }.disabled(details.cardNumber.isEmpty)
                    if !details.pin.isEmpty {
                        HStack { Text("PIN / access number"); Spacer(); Text(showPIN ? details.pin : "••••") }
                        Toggle("Show PIN", isOn: $showPIN)
                        Button("Copy PIN for 60 seconds") { copy(details.pin) }
                    }
                    if let error { Text(error).foregroundStyle(.red) }
                }
            }
            .navigationTitle("Card Details")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
            .onAppear {
                do { details = try SecureCardVault.get(CardSecrets.self, card: card.id, name: "details") ?? CardSecrets() }
                catch { self.error = error.localizedDescription }
            }
        }
    }
    private func copy(_ value: String) {
        UIPasteboard.general.setItems([[UIPasteboard.typeAutomatic: value]], options: [.localOnly: true, .expirationDate: Date().addingTimeInterval(60)])
    }
}

struct BalanceReviewView: View {
    let card: CardRecord
    let candidates: [BalanceCandidate]
    let currentURL: String?
    let saved: () -> Void
    @EnvironmentObject var store: CardStore
    @Environment(\.dismiss) private var dismiss
    @State private var amount = ""
    @State private var selected: BalanceCandidate?
    @State private var verified = false
    @State private var error: String?
    var body: some View {
        NavigationStack {
            Form {
                Section("Verify this card") {
                    Text(card.maskedInfo).font(.headline)
                    Text(URL(string: selected?.pageURL ?? currentURL ?? "")?.host ?? "Provider website").font(.caption)
                    Toggle("This is the balance for this card", isOn: $verified)
                }
                if !candidates.isEmpty {
                    Section("Balances read from the visible page") {
                        ForEach(candidates) { candidate in
                            Button {
                                selected = candidate; amount = NSDecimalNumber(decimal: candidate.amount).stringValue
                            } label: {
                                VStack(alignment: .leading, spacing: 4) {
                                    HStack { Text(candidate.display).bold(); if selected?.id == candidate.id { Image(systemName: "checkmark.circle.fill") } }
                                    Text(candidate.evidence).font(.caption).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                }
                Section("Amount shown by provider (USD)") {
                    TextField("Enter the current balance", text: $amount).keyboardType(.decimalPad)
                        .onChange(of: amount) { value in
                            if let selected, AmountParser.parse(value) != selected.amount { self.selected = nil }
                        }
                    Text("If the website can't be read automatically, enter the balance it displays here.").font(.caption)
                }
                if let error { Text(error).foregroundStyle(.red) }
            }
            .navigationTitle("Confirm Balance")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Save to Sheet") { confirm() }.disabled(!verified || AmountParser.parse(amount) == nil) }
            }
        }
    }
    private func confirm() {
        guard let value = AmountParser.parse(amount), verified,
              var current = store.cards.first(where: { $0.id == card.id }) else { return }
        current.balance = value; current.currencyCode = "USD"
        current.lastChecked = Date()
        current.balanceSource = selected == nil ? "Confirmed" : "Website"
        if let url = URL(string: selected?.pageURL ?? currentURL ?? ""), let host = url.host {
            current.balancePageURL = "https://" + host
        }
        // Persist only redacted evidence. Query strings/tokens and full card numbers stay out of JSON.
        current.balanceEvidence = selected?.evidence.replacingOccurrences(of: #"\d[\d -]{7,}\d"#, with: "••••", options: .regularExpression)
        if store.update(current) { saved(); dismiss() } else { error = store.errorMessage }
    }
}
