import SwiftUI
import UIKit
import AVFoundation

struct CameraPicker: UIViewControllerRepresentable {
    let completion: (UIImage?) -> Void
    @Environment(\.dismiss) private var dismiss
    func makeUIViewController(context: Context) -> LandscapeCameraController {
        let controller = LandscapeCameraController()
        controller.completion = { image in completion(image); dismiss() }
        return controller
    }
    func updateUIViewController(_ controller: LandscapeCameraController, context: Context) {}
    static func dismantleUIViewController(_ controller: LandscapeCameraController, coordinator: ()) { controller.engine.stop() }
}

// Capture configuration and startRunning stay off the UI thread.
final class CardCameraEngine: NSObject, AVCapturePhotoCaptureDelegate {
    let session = AVCaptureSession()
    private let queue = DispatchQueue(label: "com.sidekick.cardbalance.camera")
    private let output = AVCapturePhotoOutput()
    private var configured = false
    private var photoCompletion: ((Result<UIImage, Error>) -> Void)?
    func start(completion: @escaping (String?) -> Void) {
        queue.async {
            do {
                if !self.configured {
                    self.session.beginConfiguration()
                    defer { self.session.commitConfiguration() }
                    self.session.sessionPreset = .photo
                    guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
                        throw self.failure("No rear camera is available.")
                    }
                    let input = try AVCaptureDeviceInput(device: device)
                    guard self.session.canAddInput(input), self.session.canAddOutput(self.output) else {
                        throw self.failure("The camera could not be configured.")
                    }
                    self.session.addInput(input); self.session.addOutput(self.output)
                    self.configured = true
                }
                if !self.session.isRunning { self.session.startRunning() }
                DispatchQueue.main.async { completion(nil) }
            } catch { DispatchQueue.main.async { completion(error.localizedDescription) } }
        }
    }
    func stop() { queue.async { if self.session.isRunning { self.session.stopRunning() } } }
    func capture(orientation: AVCaptureVideoOrientation, completion: @escaping (Result<UIImage, Error>) -> Void) {
        queue.async {
            guard self.session.isRunning else {
                DispatchQueue.main.async { completion(.failure(self.failure("The camera is not ready."))) }; return
            }
            self.photoCompletion = completion
            if let connection = self.output.connection(with: .video), connection.isVideoOrientationSupported {
                connection.videoOrientation = orientation
            }
            self.output.capturePhoto(with: AVCapturePhotoSettings(), delegate: self)
        }
    }
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        let result: Result<UIImage, Error>
        if let error { result = .failure(error) }
        else if let data = photo.fileDataRepresentation(), let image = UIImage(data: data) { result = .success(image) }
        else { result = .failure(failure("No readable photo was captured.")) }
        queue.async {
            let completion = self.photoCompletion
            self.photoCompletion = nil
            DispatchQueue.main.async { completion?(result) }
        }
    }
    private func failure(_ message: String) -> NSError {
        NSError(domain: "CardBalanceCamera", code: 1, userInfo: [NSLocalizedDescriptionKey: message])
    }
}

final class LandscapeCameraController: UIViewController {
    let engine = CardCameraEngine()
    var completion: ((UIImage?) -> Void)?
    private var preview: AVCaptureVideoPreviewLayer?
    private let captureButton = UIButton(type: .system)
    private let cancelButton = UIButton(type: .system)
    private let statusLabel = UILabel()
    private var completed = false
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }
    override var prefersStatusBarHidden: Bool { true }
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        let layer = AVCaptureVideoPreviewLayer(session: engine.session)
        layer.videoGravity = .resizeAspectFill
        view.layer.addSublayer(layer); preview = layer
        cancelButton.setTitle("Cancel", for: .normal)
        cancelButton.setTitleColor(.white, for: .normal)
        cancelButton.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        cancelButton.layer.cornerRadius = 10
        cancelButton.addTarget(self, action: #selector(cancel), for: .touchUpInside)
        captureButton.setTitle("Capture card", for: .normal)
        captureButton.setTitleColor(.white, for: .normal)
        captureButton.backgroundColor = .systemGreen
        captureButton.layer.cornerRadius = 12; captureButton.isEnabled = false
        captureButton.addTarget(self, action: #selector(capture), for: .touchUpInside)
        statusLabel.text = "Keep the card inside the frame"
        statusLabel.textColor = .white; statusLabel.textAlignment = .center
        statusLabel.numberOfLines = 2; statusLabel.backgroundColor = UIColor.black.withAlphaComponent(0.55)
        for control in [cancelButton, captureButton, statusLabel] as [UIView] {
            control.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(control)
        }
        NSLayoutConstraint.activate([
            cancelButton.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 14),
            cancelButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 12),
            cancelButton.widthAnchor.constraint(equalToConstant: 84), cancelButton.heightAnchor.constraint(equalToConstant: 42),
            captureButton.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -14),
            captureButton.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            captureButton.widthAnchor.constraint(equalToConstant: 125), captureButton.heightAnchor.constraint(equalToConstant: 64),
            statusLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 110),
            statusLabel.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -150),
            statusLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -12),
            statusLabel.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized: startCamera()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                DispatchQueue.main.async {
                    if granted { self?.startCamera() }
                    else { self?.statusLabel.text = "Camera access was denied. Use Photos or Files, or enable Camera in Settings." }
                }
            }
        default: statusLabel.text = "Camera access is unavailable. Use Photos or Files, or enable Camera in Settings."
        }
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        preview?.frame = view.bounds
        if let connection = preview?.connection, connection.isVideoOrientationSupported { connection.videoOrientation = orientation }
    }
    override func viewWillDisappear(_ animated: Bool) { super.viewWillDisappear(animated); engine.stop() }
    private var orientation: AVCaptureVideoOrientation {
        view.window?.windowScene?.interfaceOrientation == .landscapeRight ? .landscapeRight : .landscapeLeft
    }
    private func startCamera() {
        guard !completed else { return }
        engine.start { [weak self] error in
            guard let self, !self.completed else { return }
            self.captureButton.isEnabled = error == nil
            if let error { self.statusLabel.text = error }
            self.view.setNeedsLayout()
        }
    }
    @objc private func cancel() { guard !completed else { return }; completed = true; engine.stop(); completion?(nil) }
    @objc private func capture() {
        captureButton.isEnabled = false
        engine.capture(orientation: orientation) { [weak self] result in
            guard let self, !self.completed else { return }
            switch result {
            case .success(let image): self.completed = true; self.engine.stop(); self.completion?(image)
            case .failure(let error): self.statusLabel.text = error.localizedDescription; self.captureButton.isEnabled = true
            }
        }
    }
}
