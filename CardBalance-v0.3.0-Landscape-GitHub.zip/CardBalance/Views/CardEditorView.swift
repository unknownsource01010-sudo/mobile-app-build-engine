import SwiftUI

struct CardEditorView: View {
    @EnvironmentObject var store: CardStore
    @Environment(\.dismiss) private var dismiss
    @State var card: CardRecord
    @State private var number = ""
    @State private var pin = ""
    @State private var amount = ""
    @State private var url = ""
    @State private var error: String?
    @State private var secretsLoaded = false
    @State private var forget = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Spreadsheet row") {
                    TextField("Company / provider", text: $card.issuer)
                    ProviderPicker(issuer: $card.issuer, url: $url)
                    TextField("Card nickname", text: $card.nickname)
                    TextField("Full card number", text: $number).keyboardType(.numberPad)
                    SecureField("Card PIN / access number (optional)", text: $pin).keyboardType(.numberPad)
                    TextField("Last four (if full number unavailable)", text: $card.last4).keyboardType(.numberPad)
                    Text("Full numbers are shown in the sheet and saved in Keychain. PINs and logins stay out of the sheet and CSV.").font(.caption).foregroundStyle(.secondary)
                }
                Section("Balance") {
                    TextField("Amount (USD)", text: $amount).keyboardType(.decimalPad)
                    Text("Editing an amount marks it Manual. Use Check to read the provider's balance.").font(.caption)
                    TextField("Notes", text: $card.notes, axis: .vertical)
                }
                Section("Balance website") {
                    TextField("https://provider.example", text: $url).keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                }
                Section("Saved access") {
                    Button("Forget saved logins for this card", role: .destructive) { forget = true }
                }
                if let error { Section { Text(error).foregroundStyle(.red) } }
            }
            .navigationTitle("Edit Card")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Save") { save() }.disabled(!secretsLoaded) }
            }
            .onAppear { load() }
            .alert("Forget logins?", isPresented: $forget) {
                Button("Forget", role: .destructive) {
                    do {
                        try SecureCardVault.deleteLogins(card.id)
                    } catch { self.error = error.localizedDescription }
                }
                Button("Cancel", role: .cancel) {}
            } message: { Text("The number and PIN stay saved. Website logins are erased.") }
        }
    }
    private func load() {
        guard !secretsLoaded else { return }
        url = card.officialBalanceURL ?? ""
        amount = card.balance.map { NSDecimalNumber(decimal: $0).stringValue } ?? ""
        do {
            if let details = try SecureCardVault.get(CardSecrets.self, card: card.id, name: "details") { number = details.cardNumber; pin = details.pin }
            secretsLoaded = true
        } catch { self.error = "Could not open secure card details: \(error.localizedDescription)" }
    }
    private func save() {
        guard url.isEmpty || IssuerDirectory.secureURL(url) != nil else { error = "Use a complete HTTPS website address."; return }
        let trimmed = amount.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.isEmpty || AmountParser.parse(trimmed) != nil else { error = "Enter a valid amount, such as 25.50."; return }
        let digits = number.filter(\.isNumber)
        guard digits.isEmpty || (8...30).contains(digits.count) else { error = "Check the full card number."; return }
        do { try SecureCardVault.put(CardSecrets(cardNumber: digits, pin: pin), card: card.id, name: "details") }
        catch { self.error = error.localizedDescription; return }
        if !digits.isEmpty { card.last4 = String(digits.suffix(4)) }
        let nextAmount = AmountParser.parse(trimmed)
        if nextAmount != card.balance { card.balance = nextAmount; card.balanceSource = "Manual"; card.lastChecked = nil; card.balanceEvidence = nil; card.balancePageURL = nil }
        card.officialBalanceURL = url.isEmpty ? nil : url.trimmingCharacters(in: .whitespacesAndNewlines)
        if card.nickname.isEmpty { card.nickname = card.issuer.isEmpty ? "Card" : card.issuer }
        if store.update(card) { dismiss() }
    }
}

struct ProviderPicker: View {
    @Binding var issuer: String
    @Binding var url: String
    var body: some View {
        Menu("Choose known company / provider") {
            ForEach(IssuerDirectory.all) { provider in
                Button(provider.name) { issuer = provider.name; url = provider.url }
            }
        }
    }
}
