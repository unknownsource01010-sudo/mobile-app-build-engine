import SwiftUI

struct BatchReviewView: View {
    @EnvironmentObject var store: CardStore
    @Environment(\.dismiss) private var dismiss
    @State var drafts: [DraftCard]
    @State private var error: String?

    var body: some View {
        NavigationStack {
            List {
                ForEach($drafts) { $draft in
                    Section(draft.sourceLabel.isEmpty ? "Scanned Card" : draft.sourceLabel) {
                        TextField("Company / provider", text: $draft.issuer)
                        ProviderPicker(issuer: $draft.issuer, url: $draft.officialURL)
                        TextField("Nickname", text: $draft.nickname)
                        TextField("Full card number — confirm the scan", text: $draft.cardNumber).keyboardType(.numberPad)
                        SecureField("PIN / access number (optional)", text: $draft.pin).keyboardType(.numberPad)
                        TextField("Last 4", text: $draft.last4).keyboardType(.numberPad)
                        TextField("Balance — leave blank to check live", text: $draft.balance).keyboardType(.decimalPad)
                        TextField("HTTPS balance website", text: $draft.officialURL).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                        TextField("Notes", text: $draft.notes)
                        Toggle("Save full number / PIN in Keychain", isOn: $draft.rememberCard)
                        Text("The saved full number appears in the spreadsheet. Review the company and website before saving.").font(.caption).foregroundStyle(.secondary)
                        if let index = drafts.firstIndex(where: { $0.id == draft.id }), index > 0 {
                            Button("Merge this back scan into the previous card") { merge(at: index) }
                        }
                        if !draft.rawText.isEmpty {
                            DisclosureGroup("Text read from image") { Text(draft.rawText).font(.caption).textSelection(.enabled) }
                        }
                    }
                }.onDelete { drafts.remove(atOffsets: $0) }
                if let error { Section { Text(error).foregroundStyle(.red) } }
            }
            .navigationTitle("Review \(drafts.count) card\(drafts.count == 1 ? "" : "s")")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Save All") { saveAll() }.disabled(drafts.isEmpty) }
            }
        }
    }
    private func merge(at index: Int) {
        guard drafts.indices.contains(index), index > 0 else { return }
        let back = drafts[index]
        if drafts[index - 1].issuer.isEmpty { drafts[index - 1].issuer = back.issuer }
        if drafts[index - 1].officialURL.isEmpty { drafts[index - 1].officialURL = back.officialURL }
        if drafts[index - 1].cardNumber.isEmpty { drafts[index - 1].cardNumber = back.cardNumber; drafts[index - 1].last4 = back.last4 }
        if drafts[index - 1].pin.isEmpty { drafts[index - 1].pin = back.pin }
        drafts[index - 1].rawText += "\n— Back scan —\n" + back.rawText
        drafts.remove(at: index)
    }
    private func saveAll() {
        for draft in drafts {
            guard draft.balance.isEmpty || AmountParser.parse(draft.balance) != nil else { error = "Check the balance in \(draft.sourceLabel)."; return }
            guard draft.officialURL.isEmpty || IssuerDirectory.secureURL(draft.officialURL) != nil else { error = "Check the HTTPS website in \(draft.sourceLabel)."; return }
            let digits = draft.cardNumber.filter(\.isNumber)
            guard digits.isEmpty || (8...30).contains(digits.count) else { error = "Check the full number in \(draft.sourceLabel)."; return }
        }
        // Remove each successfully saved draft, so retrying after a storage error cannot duplicate it.
        while let draft = drafts.first {
            let amount = AmountParser.parse(draft.balance)
            let digits = draft.cardNumber.filter(\.isNumber)
            let name = draft.nickname.isEmpty ? (draft.issuer.isEmpty ? "Card" : draft.issuer) : draft.nickname
            var card = CardRecord(issuer: draft.issuer, nickname: name,
                                  last4: digits.isEmpty ? String(draft.last4.filter(\.isNumber).suffix(4)) : String(digits.suffix(4)),
                                  balance: amount, lastChecked: nil, notes: draft.notes,
                                  officialBalanceURL: draft.officialURL.isEmpty ? nil : draft.officialURL)
            card.balanceSource = amount == nil ? nil : "Manual"
            if draft.rememberCard {
                do { try SecureCardVault.put(CardSecrets(cardNumber: digits, pin: draft.pin), card: card.id, name: "details") }
                catch { self.error = "Secure save failed: \(error.localizedDescription)"; return }
            }
            guard store.add(card) else {
                try? SecureCardVault.deleteCard(card.id)
                error = store.errorMessage; return
            }
            drafts.removeFirst()
        }
        dismiss()
    }
}
