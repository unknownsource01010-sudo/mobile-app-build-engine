import SwiftUI
import UniformTypeIdentifiers
import UIKit

struct DocumentPicker: UIViewControllerRepresentable {
    let completion: ([URL]) -> Void
    @Environment(\.dismiss) private var dismiss

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker=UIDocumentPickerViewController(forOpeningContentTypes:[.image],asCopy:true)
        picker.allowsMultipleSelection=true
        picker.delegate=context.coordinator
        return picker
    }
    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator(self) }

    final class Coordinator:NSObject,UIDocumentPickerDelegate {
        let parent:DocumentPicker
        init(_ p:DocumentPicker){parent=p}
        func documentPicker(_ controller:UIDocumentPickerViewController,didPickDocumentsAt urls:[URL]){
            parent.completion(urls); parent.dismiss()
        }
        func documentPickerWasCancelled(_ controller:UIDocumentPickerViewController){
            parent.completion([]); parent.dismiss()
        }
    }
}
