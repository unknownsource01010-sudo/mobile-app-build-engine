import SwiftUI
import UIKit
import AVFoundation

struct AddCardView: View {
    @EnvironmentObject var store: CardStore
    @Environment(\.dismiss) private var dismiss

    @State private var showCamera=false
    @State private var showPhotos=false
    @State private var showFiles=false
    @State private var showReview=false
    @State private var busy=false
    @State private var status=""
    @State private var drafts:[DraftCard]=[]
    @State private var pendingItems:[(UIImage,String)]=[]

    var body: some View {
        NavigationStack {
            Form {
                Section("Import") {
                    Button("Camera") { showCamera=true }.disabled(AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) == nil)
                    Button("Add card manually") { drafts=[DraftCard(sourceLabel:"Manual entry",rememberCard:true)]; showReview=true }
                    Button("Photos — select one or many") { showPhotos=true }
                    Button("Files — select one or many") { showFiles=true }
                }.disabled(busy)
                Section("Batch") {
                    if busy { ProgressView(status.isEmpty ? "Reading cards…" : status) }
                    else if !status.isEmpty { Text(status).font(.footnote) }
                    Text("Each image becomes a review row. Scan a front and back in that order, then use Merge to combine them. Confirm the company, website and full card number before saving.")
                        .font(.footnote)
                }
                Section("Privacy") {
                    Text("Images are read on this iPhone and are not retained. Confirmed full numbers and optional PINs are saved in Keychain; the spreadsheet file stores only the last four. Passwords are requested in the checker when needed.")
                        .font(.footnote)
                }
            }
            .navigationTitle("Scan / Import")
            .toolbar { ToolbarItem(placement:.cancellationAction){Button("Close"){dismiss()}} }
            .sheet(isPresented:$showCamera,onDismiss:startPending) {
                CameraPicker { image in if let image { pendingItems=[(image,"Camera")] } }
            }
            .sheet(isPresented:$showPhotos,onDismiss:startPending) {
                MultiPhotoPicker { images in
                    if !images.isEmpty { pendingItems=images.enumerated().map{($0.element,"Photo \($0.offset+1)")} }
                }
            }
            .sheet(isPresented:$showFiles,onDismiss:startPending) {
                DocumentPicker { urls in
                    let items=urls.compactMap { url -> (UIImage,String)? in
                        guard let data=try? Data(contentsOf:url),let image=UIImage(data:data) else{return nil}
                        return (image,url.lastPathComponent)
                    }
                    if !items.isEmpty { pendingItems=items }
                    else { status="No readable image files were selected." }
                }
            }
            .sheet(isPresented:$showReview,onDismiss:{drafts=[]}) {
                BatchReviewView(drafts:drafts).environmentObject(store)
            }
        }
    }

    private func startPending() {
        guard !pendingItems.isEmpty, !busy else { return }
        let items=pendingItems
        pendingItems=[]
        Task { await process(items) }
    }

    @MainActor private func process(_ items:[(UIImage,String)]) async {
        busy=true; drafts=[]; status="Reading 0 of \(items.count)…"
        for (i,item) in items.enumerated() {
            status="Reading \(i+1) of \(items.count)…"
            do {
                let result = try await CardScanner.scan(item.0)
                drafts.append(DraftCard(issuer:result.issuer,last4:result.last4,sourceLabel:item.1,rawText:result.rawText,officialURL:result.officialURL,cardNumber:result.cardNumber,rememberCard:true))
            } catch {
                drafts.append(DraftCard(sourceLabel:item.1,rawText:"OCR could not read this image.",rememberCard:true))
            }
        }
        busy=false
        status="Ready to review \(drafts.count) item\(drafts.count == 1 ? "" : "s")."
        if !drafts.isEmpty { showReview=true }
    }
}
