import SwiftUI
import PhotosUI
import UIKit

struct MultiPhotoPicker: UIViewControllerRepresentable {
    let completion: ([UIImage]) -> Void
    @Environment(\.dismiss) private var dismiss

    func makeUIViewController(context: Context) -> PHPickerViewController {
        var config=PHPickerConfiguration(photoLibrary: .shared())
        config.filter = .images
        config.selectionLimit = 0
        let picker=PHPickerViewController(configuration: config)
        picker.delegate=context.coordinator
        return picker
    }
    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator(self) }

    final class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let parent: MultiPhotoPicker
        init(_ p: MultiPhotoPicker) { parent=p }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            guard !results.isEmpty else { parent.completion([]); parent.dismiss(); return }
            let group=DispatchGroup()
            let lock=NSLock()
            var loaded:[(Int,UIImage)] = []
            for (index,result) in results.enumerated() where result.itemProvider.canLoadObject(ofClass: UIImage.self) {
                group.enter()
                result.itemProvider.loadObject(ofClass: UIImage.self) { object,_ in
                    if let img=object as? UIImage {
                        lock.lock(); loaded.append((index,img)); lock.unlock()
                    }
                    group.leave()
                }
            }
            group.notify(queue:.main) {
                self.parent.completion(loaded.sorted{$0.0<$1.0}.map{$0.1})
                self.parent.dismiss()
            }
        }
    }
}
