import SwiftUI
import UIKit

private enum CardSort: String, CaseIterable { case company = "Company", card = "Card", balance = "Balance", checked = "Checked" }

struct ContentView: View {
    @EnvironmentObject var store: CardStore
    @Environment(\.scenePhase) private var scenePhase
    @State private var query = ""
    @State private var sort: CardSort = .company
    @State private var ascending = true
    @State private var showNumbers = true
    @State private var numbers: [UUID: String] = [:]
    @State private var add = false
    @State private var editCard: CardRecord?
    @State private var checkCard: CardRecord?
    @State private var deleteCard: CardRecord?
    @State private var confirmDelete = false
    @State private var shareURL: ExportFile?
    private let green = Color(red: 0.08, green: 0.38, blue: 0.26)

    private var visible: [CardRecord] {
        let rows = store.cards.filter { query.isEmpty || ($0.issuer + " " + $0.nickname + " " + $0.last4 + " " + $0.notes).localizedCaseInsensitiveContains(query) }
        return rows.sorted { a, b in
            let order: Bool
            switch sort {
            case .company: order = a.issuer.localizedStandardCompare(b.issuer) == .orderedAscending
            case .card: order = a.nickname.localizedStandardCompare(b.nickname) == .orderedAscending
            case .balance: order = (a.balance ?? -1) < (b.balance ?? -1)
            case .checked: order = (a.lastChecked ?? .distantPast) < (b.lastChecked ?? .distantPast)
            }
            let reverse: Bool
            switch sort {
            case .company: reverse = b.issuer.localizedStandardCompare(a.issuer) == .orderedAscending
            case .card: reverse = b.nickname.localizedStandardCompare(a.nickname) == .orderedAscending
            case .balance: reverse = (b.balance ?? -1) < (a.balance ?? -1)
            case .checked: reverse = (b.lastChecked ?? .distantPast) < (a.lastChecked ?? .distantPast)
            }
            return ascending ? order : reverse
        }
    }
    private var totals: String {
        let groups = Dictionary(grouping: store.cards.filter { $0.balance != nil }, by: \.currency)
        return groups.keys.sorted().map { code in
            let amount = groups[code, default: []].compactMap(\.balance).reduce(Decimal.zero, +)
            let formatter = NumberFormatter(); formatter.numberStyle = .currency; formatter.currencyCode = code
            return (formatter.string(from: amount as NSDecimalNumber) ?? "\(amount)") + " " + code
        }.joined(separator: "   •   ")
    }

    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                toolbar
                    .padding(.leading, max(12, geometry.safeAreaInsets.leading))
                    .padding(.trailing, max(12, geometry.safeAreaInsets.trailing))
                HStack(spacing: 14) {
                    Label("\(store.cards.count) cards", systemImage: "rectangle.stack")
                    Text("Known total  " + (totals.isEmpty ? "—" : totals)).bold()
                    Spacer()
                    Text("\(store.cards.filter { $0.balance == nil }.count) unchecked").foregroundStyle(.secondary)
                }
                .font(.caption).padding(.horizontal, 18).padding(.vertical, 7)
                .background(Color(red: 0.91, green: 0.95, blue: 0.93))
                spreadsheet
                HStack {
                    Text("Tap a cell to edit • Check opens the card's balance provider")
                    Spacer()
                    Text("CSV opens in Excel / Numbers")
                }.font(.caption2).foregroundStyle(.secondary).padding(.horizontal, 18).padding(.vertical, 6)
            }
            .background(Color.white)
            .frame(width: geometry.size.width + geometry.safeAreaInsets.leading + geometry.safeAreaInsets.trailing,
                   height: geometry.size.height)
            .offset(x: -geometry.safeAreaInsets.leading)
        }
        .background(Color.white.ignoresSafeArea())
        .preferredColorScheme(.light)
        .statusBarHidden(true)
        .onAppear { loadNumbers() }
        .onChange(of: store.cards) { _ in loadNumbers() }
        .onChange(of: scenePhase) { phase in
            if phase != .active { showNumbers = false; numbers = [:] }
        }
        .fullScreenCover(isPresented: $add) { AddCardView().environmentObject(store) }
        .sheet(item: $editCard) { CardEditorView(card: $0).environmentObject(store) }
        .fullScreenCover(item: $checkCard) { BalanceCheckView(card: $0).environmentObject(store) }
        .sheet(item: $shareURL) { ActivityView(items: [$0.url]) }
        .alert("Delete this card?", isPresented: $confirmDelete, presenting: deleteCard) { card in
            Button("Delete", role: .destructive) { store.delete(id: card.id); deleteCard = nil }
            Button("Cancel", role: .cancel) { deleteCard = nil }
        } message: { _ in Text("This removes the row and its saved login and card details.") }
        .alert("Could not save", isPresented: Binding(get: { store.errorMessage != nil }, set: { if !$0 { store.errorMessage = nil } })) {
            Button("OK") { store.errorMessage = nil }
        } message: { Text(store.errorMessage ?? "") }
    }
    private var toolbar: some View {
        HStack(spacing: 12) {
            Image(systemName: "tablecells.fill").foregroundStyle(green)
            Text("CardBalance").font(.title3.bold())
            HStack {
                Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                TextField("Find company or card", text: $query).textInputAutocapitalization(.never)
            }.padding(8).background(Color(.systemGray6)).clipShape(RoundedRectangle(cornerRadius: 7))
            Button {
                showNumbers.toggle(); if showNumbers { loadNumbers() }
            } label: { Label(showNumbers ? "Hide numbers" : "Full numbers", systemImage: showNumbers ? "eye.slash" : "eye") }
            Button { exportCSV() } label: { Label("Export", systemImage: "square.and.arrow.up") }
            Button { add = true } label: { Label("Add / Scan", systemImage: "plus") }
                .buttonStyle(.borderedProminent).tint(green)
        }.font(.subheadline).padding(.vertical, 8)
    }
    private var spreadsheet: some View {
        GeometryReader { geometry in
            ScrollView(.horizontal) {
                VStack(spacing: 0) {
                    HStack(spacing: 0) {
                        header("#", width: 40)
                        header("A  Company", width: 155, sort: .company)
                        header("B  Card", width: 145, sort: .card)
                        header("C  Card number", width: 190)
                        header("D  Balance", width: 112, sort: .balance)
                        header("E  Checked", width: 145, sort: .checked)
                        header("F  Source", width: 90)
                        header("G  Notes", width: 180)
                        header("Actions", width: 112)
                    }.background(green).foregroundStyle(.white)
                    ScrollView(.vertical) {
                        LazyVStack(spacing: 0) {
                            ForEach(Array(visible.enumerated()), id: \.element.id) { index, card in
                                row(card, index: index)
                            }
                            if visible.isEmpty {
                                VStack(spacing: 12) {
                                    Image(systemName: "creditcard.viewfinder").font(.largeTitle).foregroundStyle(green)
                                    Text(store.cards.isEmpty ? "Your card spreadsheet" : "No matching cards").font(.headline)
                                    Text("Scan photos, use the camera, or add a card manually.").foregroundStyle(.secondary)
                                    Button("Add / Scan") { add = true }.buttonStyle(.borderedProminent).tint(green)
                                }.frame(width: 1169, height: max(170, geometry.size.height - 42))
                            }
                        }
                    }.frame(maxHeight: .infinity)
                }.frame(width: 1169, height: geometry.size.height)
            }
        }
    }
    private func header(_ title: String, width: CGFloat, sort column: CardSort? = nil) -> some View {
        Button {
            guard let column else { return }
            if sort == column { ascending.toggle() } else { sort = column; ascending = true }
        } label: {
            HStack(spacing: 4) {
                Text(title).lineLimit(1)
                if let column, sort == column { Image(systemName: ascending ? "chevron.up" : "chevron.down").font(.caption2) }
            }.frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 9)
                .frame(width: width, height: 38).overlay(alignment: .trailing) { Color.white.opacity(0.25).frame(width: 1) }
        }.buttonStyle(.plain).font(.caption.bold())
    }
    private func cell(_ text: String, width: CGFloat, numeric: Bool = false) -> some View {
        Text(text).font(numeric ? .system(size: 12, design: .monospaced) : .system(size: 13))
            .lineLimit(1).frame(maxWidth: .infinity, alignment: numeric ? .trailing : .leading)
            .padding(.horizontal, 9).frame(width: width, height: 46)
            .overlay(alignment: .trailing) { Color(.systemGray4).frame(width: 0.5) }
    }
    private func row(_ card: CardRecord, index: Int) -> some View {
        HStack(spacing: 0) {
            cell("\(index + 1)", width: 40, numeric: true).foregroundStyle(.secondary)
            Button { editCard = card } label: {
                HStack(spacing: 0) {
                    cell(card.issuer.isEmpty ? "Choose provider" : card.issuer, width: 155)
                    cell(card.nickname, width: 145)
                    cell(showNumbers ? (numbers[card.id] ?? ("•••• " + card.last4)) : ("•••• " + card.last4), width: 190, numeric: true)
                    cell(card.money, width: 112, numeric: true)
                    cell(card.lastChecked?.formatted(date: .numeric, time: .shortened) ?? "Not checked", width: 145)
                    cell(card.balanceSource ?? "Saved", width: 90)
                    cell(card.notes, width: 180)
                }
            }.buttonStyle(.plain)
            HStack(spacing: 8) {
                Button("Check") { checkCard = card }.buttonStyle(.bordered).tint(green)
                Button { deleteCard = card; confirmDelete = true } label: { Image(systemName: "trash") }.foregroundStyle(.red).accessibilityLabel("Delete \(card.nickname)")
            }.font(.caption).frame(width: 112, height: 46)
        }
        .contextMenu {
            Button("Check balance") { checkCard = card }
            Button("Edit card") { editCard = card }
            Button("Delete card", role: .destructive) { deleteCard = card; confirmDelete = true }
        }
        .background(index.isMultiple(of: 2) ? Color.white : Color(red: 0.96, green: 0.98, blue: 0.97))
        .overlay(alignment: .bottom) { Color(.systemGray4).frame(height: 0.5) }
    }
    private func loadNumbers() {
        guard showNumbers else { return }
        var loaded: [UUID: String] = [:]
        for card in store.cards {
            if let secret = try? SecureCardVault.get(CardSecrets.self, card: card.id, name: "details"), !secret.cardNumber.isEmpty {
                loaded[card.id] = secret.cardNumber
            }
        }
        numbers = loaded
    }
    private func exportCSV() {
        do {
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("card-balances.csv")
            try store.csv().write(to: url, atomically: true, encoding: .utf8)
            shareURL = ExportFile(url: url)
        } catch { store.errorMessage = "Export failed: \(error.localizedDescription)" }
    }
}
struct ExportFile: Identifiable { let id = UUID(); let url: URL }
struct ActivityView: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: items, applicationActivities: nil) }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
