# Bounty Bot Native iOS

Native SwiftUI build. No WKWebView, no PWA wrapper.

## Visual assets
The cyber-western artwork is bundled inside the app as PNG resources (`Resources/*.png`) and rendered with native SwiftUI. The event cinematics use native animation layers on top of those PNGs, including the DEAL LOST falling jail bars, NEW DEAL pulse, HIGH NOON glare, and moving TRAIN HUNT sequence.

## Build
```bash
brew install xcodegen
xcodegen generate
xcodebuild -project BountyBotNative.xcodeproj -scheme BountyBotNative -configuration Release -sdk iphoneos CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" build
```

The GitHub workflow included with the release package produces an unsigned IPA for sideload signing.
