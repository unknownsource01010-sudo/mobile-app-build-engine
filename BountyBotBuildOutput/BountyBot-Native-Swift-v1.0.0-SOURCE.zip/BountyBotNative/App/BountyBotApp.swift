import SwiftUI
import Charts
import AVFoundation
import UIKit

@main
struct BountyBotApp: App {
    @StateObject private var store = DealStore()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .preferredColorScheme(.dark)
        }
    }
}

// MARK: - Models

struct Deal: Identifiable, Hashable {
    let id: UUID
    let title: String
    let category: String
    let store: String
    let currentPrice: Double
    let originalPrice: Double
    let rating: Double
    let reviews: Int
    let symbol: String
    let url: URL
    let history: [PricePoint]

    var discountPercent: Int {
        guard originalPrice > 0 else { return 0 }
        return Int(((originalPrice - currentPrice) / originalPrice * 100).rounded())
    }

    var savings: Double { max(0, originalPrice - currentPrice) }
}

struct PricePoint: Identifiable, Hashable {
    let id = UUID()
    let day: Int
    let price: Double
}

enum AppTab: String, CaseIterable, Identifiable {
    case home = "Home"
    case deals = "Deals"
    case track = "Track"
    case tools = "Tools"
    case more = "More"
    var id: String { rawValue }

    var icon: String {
        switch self {
        case .home: return "house.fill"
        case .deals: return "tag.fill"
        case .track: return "chart.line.uptrend.xyaxis"
        case .tools: return "wrench.and.screwdriver.fill"
        case .more: return "ellipsis"
        }
    }
}

enum DealEvent: Equatable {
    case lost(Deal)
    case newDeal(Deal)
    case priceDrop(Deal)
    case secured(Deal)
    case highNoon
    case trainRun

    var title: String {
        switch self {
        case .lost: return "DEAL LOST"
        case .newDeal: return "NEW DEAL"
        case .priceDrop: return "PRICE DROP"
        case .secured: return "DEAL SECURED"
        case .highNoon: return "HIGH NOON"
        case .trainRun: return "HUNT IN MOTION"
        }
    }

    var assetName: String {
        switch self {
        case .lost: return "lost"
        case .newDeal: return "newdeal"
        case .priceDrop: return "pricedrop"
        case .secured: return "hero"
        case .highNoon: return "highnoon"
        case .trainRun: return "train"
        }
    }
}

@MainActor
final class DealStore: ObservableObject {
    @Published var favorites: Set<UUID> = []
    @Published var tracked: Set<UUID> = []
    @Published var selectedTab: AppTab = .home
    @Published var event: DealEvent? = nil
    @Published var alertsEnabled = true
    @Published var autoBuyEnabled = false
    @Published var autoBuyLimit: Double = 150

    let deals: [Deal] = [
        Deal(id: UUID(uuidString: "8D56E77A-00D8-4C3F-94BE-17F1B7061111")!, title: "PlayStation 5 Slim", category: "Electronics", store: "Amazon", currentPrice: 389, originalPrice: 499, rating: 4.8, reviews: 2410, symbol: "gamecontroller.fill", url: URL(string: "https://www.amazon.com/s?k=PlayStation+5+Slim")!, history: DealStore.history([499,489,472,449,430,419,415,399,405,389])),
        Deal(id: UUID(uuidString: "8D56E77A-00D8-4C3F-94BE-17F1B7062222")!, title: "DEWALT 20V MAX Drill Kit", category: "Tools", store: "Home Depot", currentPrice: 129, originalPrice: 199, rating: 4.8, reviews: 1200, symbol: "hammer.fill", url: URL(string: "https://www.homedepot.com/s/dewalt%2020v%20drill")!, history: DealStore.history([199,189,179,169,169,159,149,139,129,129])),
        Deal(id: UUID(uuidString: "8D56E77A-00D8-4C3F-94BE-17F1B7063333")!, title: "Traeger Pro 575 Grill", category: "Outdoors", store: "Walmart", currentPrice: 579, originalPrice: 799, rating: 4.7, reviews: 820, symbol: "flame.fill", url: URL(string: "https://www.walmart.com/search?q=Traeger+Pro+575")!, history: DealStore.history([799,779,749,719,699,659,629,619,589,579])),
        Deal(id: UUID(uuidString: "8D56E77A-00D8-4C3F-94BE-17F1B7064444")!, title: "AirPods Pro 2", category: "Electronics", store: "Best Buy", currentPrice: 189, originalPrice: 249, rating: 4.9, reviews: 8600, symbol: "airpodspro", url: URL(string: "https://www.bestbuy.com/site/searchpage.jsp?st=airpods+pro+2")!, history: DealStore.history([249,239,229,219,219,209,199,199,189,189])),
        Deal(id: UUID(uuidString: "8D56E77A-00D8-4C3F-94BE-17F1B7065555")!, title: "Ninja Air Fryer", category: "Home", store: "Amazon", currentPrice: 89, originalPrice: 129, rating: 4.7, reviews: 18400, symbol: "takeoutbag.and.cup.and.straw.fill", url: URL(string: "https://www.amazon.com/s?k=Ninja+Air+Fryer")!, history: DealStore.history([129,129,119,109,109,99,99,94,89,89])),
        Deal(id: UUID(uuidString: "8D56E77A-00D8-4C3F-94BE-17F1B7066666")!, title: "DJI Mini 4 Pro", category: "Electronics", store: "Best Buy", currentPrice: 679, originalPrice: 999, rating: 4.8, reviews: 2400, symbol: "camera.metering.center.weighted", url: URL(string: "https://www.bestbuy.com/site/searchpage.jsp?st=DJI+Mini+4+Pro")!, history: DealStore.history([999,949,899,849,799,759,739,699,679,679]))
    ]

    static func history(_ values: [Double]) -> [PricePoint] {
        values.enumerated().map { PricePoint(day: $0.offset, price: $0.element) }
    }

    func toggleFavorite(_ deal: Deal) {
        if favorites.contains(deal.id) { favorites.remove(deal.id) }
        else { favorites.insert(deal.id); haptic(.success) }
    }

    func toggleTrack(_ deal: Deal) {
        if tracked.contains(deal.id) { tracked.remove(deal.id) }
        else { tracked.insert(deal.id); event = .secured(deal); haptic(.success) }
    }

    func haptic(_ type: UINotificationFeedbackGenerator.FeedbackType) {
        UINotificationFeedbackGenerator().notificationOccurred(type)
    }

    func runHunt() {
        guard event == nil else { return }
        event = .trainRun
        UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 2_250_000_000)
            event = .highNoon
            try? await Task.sleep(nanoseconds: 1_850_000_000)
            event = .newDeal(deals[0])
            try? await Task.sleep(nanoseconds: 2_350_000_000)
            event = nil
        }
    }
}

// MARK: - Root

struct RootView: View {
    @EnvironmentObject private var store: DealStore
    @State private var showSplash = true

    var body: some View {
        ZStack {
            Color.bbBlack.ignoresSafeArea()
            MainShell()
                .opacity(showSplash ? 0 : 1)

            if let event = store.event {
                DealEventOverlay(event: event) {
                    withAnimation(.easeOut(duration: 0.25)) { store.event = nil }
                }
                .zIndex(20)
            }

            if showSplash {
                SplashView {
                    withAnimation(.easeOut(duration: 0.45)) { showSplash = false }
                }
                .zIndex(30)
            }
        }
    }
}

struct SplashView: View {
    let finish: () -> Void
    @State private var zoom = 0.88
    @State private var glow = 0.2
    @State private var flash = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            ExactPNG("hero")
                .scaledToFit()
                .scaleEffect(zoom)
                .shadow(color: Color.bbGold.opacity(glow), radius: 38)
                .overlay {
                    if flash {
                        RadialGradient(colors: [.white.opacity(0.95), .bbGold.opacity(0.42), .clear], center: .center, startRadius: 2, endRadius: 260)
                            .blendMode(.screen)
                            .transition(.opacity)
                    }
                }
                .padding(.horizontal, 8)

            VStack {
                Spacer()
                HStack(spacing: 8) {
                    Circle().fill(Color.bbGold).frame(width: 7, height: 7)
                    Text("NATIVE iOS • HUNT ENGINE ONLINE")
                        .font(.system(size: 11, weight: .black, design: .rounded))
                        .tracking(1.4)
                        .foregroundStyle(Color.bbGold)
                    Circle().fill(Color.bbGold).frame(width: 7, height: 7)
                }
                .padding(.bottom, 34)
            }
        }
        .task {
            withAnimation(.spring(response: 0.75, dampingFraction: 0.72)) { zoom = 1.0; glow = 0.9 }
            try? await Task.sleep(nanoseconds: 650_000_000)
            withAnimation(.easeOut(duration: 0.08)) { flash = true }
            UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
            try? await Task.sleep(nanoseconds: 120_000_000)
            withAnimation(.easeOut(duration: 0.28)) { flash = false }
            try? await Task.sleep(nanoseconds: 1_050_000_000)
            finish()
        }
    }
}

struct MainShell: View {
    @EnvironmentObject private var store: DealStore

    var body: some View {
        VStack(spacing: 0) {
            Group {
                switch store.selectedTab {
                case .home: HomeView()
                case .deals: DealsView()
                case .track: TrackView()
                case .tools: ToolsView()
                case .more: MoreView()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)

            NativeTabBar()
        }
        .background(Color.bbBlack.ignoresSafeArea())
    }
}

struct NativeTabBar: View {
    @EnvironmentObject private var store: DealStore
    var body: some View {
        HStack(spacing: 2) {
            ForEach(AppTab.allCases) { tab in
                Button {
                    withAnimation(.spring(response: 0.32, dampingFraction: 0.78)) { store.selectedTab = tab }
                    UISelectionFeedbackGenerator().selectionChanged()
                } label: {
                    VStack(spacing: 3) {
                        Image(systemName: tab.icon).font(.system(size: 18, weight: .bold))
                        Text(tab.rawValue).font(.system(size: 9, weight: .bold))
                    }
                    .foregroundStyle(store.selectedTab == tab ? Color.bbGold : Color.white.opacity(0.64))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                    .background {
                        if store.selectedTab == tab {
                            RoundedRectangle(cornerRadius: 12).fill(Color.bbGold.opacity(0.10))
                        }
                    }
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 8)
        .padding(.top, 5)
        .padding(.bottom, 4)
        .background(.ultraThinMaterial)
        .overlay(alignment: .top) { Rectangle().fill(Color.bbGold.opacity(0.55)).frame(height: 1) }
    }
}

// MARK: - Home

struct HomeView: View {
    @EnvironmentObject private var store: DealStore
    @State private var sceneIndex = 0
    private let scenes = ["hero", "newdeal", "highnoon", "train", "lost", "pricedrop"]

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 14) {
                TopHeader(title: "BOUNTY BOT", subtitle: "DEAL HUNTER")

                ZStack(alignment: .bottom) {
                    SceneCard(asset: scenes[sceneIndex], height: 282)
                        .id(sceneIndex)
                        .transition(.opacity.combined(with: .scale(scale: 1.03)))

                    HStack {
                        Button {
                            withAnimation(.easeInOut(duration: 0.35)) { sceneIndex = (sceneIndex - 1 + scenes.count) % scenes.count }
                        } label: { CircleIcon("chevron.left") }
                        Spacer()
                        Button {
                            withAnimation(.easeInOut(duration: 0.35)) { sceneIndex = (sceneIndex + 1) % scenes.count }
                        } label: { CircleIcon("chevron.right") }
                    }
                    .padding(12)
                }
                .padding(.horizontal, 12)

                Button(action: store.runHunt) {
                    HStack(spacing: 10) {
                        Image(systemName: "scope").font(.title2.bold())
                        VStack(alignment: .leading, spacing: 1) {
                            Text("HUNT FOR DEALS").font(.system(size: 18, weight: .black, design: .rounded))
                            Text("Train run → high noon → match found").font(.system(size: 10, weight: .semibold))
                        }
                        Spacer()
                        Image(systemName: "bolt.fill")
                    }
                    .foregroundStyle(Color.black)
                    .padding(.horizontal, 16).padding(.vertical, 13)
                    .background(LinearGradient(colors: [Color.bbGoldBright, Color.bbGold], startPoint: .top, endPoint: .bottom))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.white.opacity(0.25), lineWidth: 1))
                }
                .buttonStyle(.plain)
                .padding(.horizontal, 12)

                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 9) {
                    HomeCommand(title: "DEALS", icon: "cart.fill") { store.selectedTab = .deals }
                    HomeCommand(title: "COMPARE", icon: "scalemass.fill") { store.selectedTab = .deals }
                    HomeCommand(title: "TRACK", icon: "chart.bar.fill") { store.selectedTab = .track }
                    HomeCommand(title: "AUTO BUY", icon: "shippingbox.fill") { store.selectedTab = .tools }
                    HomeCommand(title: "WATCHLIST", icon: "scope") { store.selectedTab = .track }
                    HomeCommand(title: "FAVORITES", icon: "star.fill") { store.selectedTab = .deals }
                }
                .padding(.horizontal, 12)

                SectionTitle("HOT BOUNTIES")
                ForEach(store.deals.prefix(3)) { deal in
                    DealRow(deal: deal)
                }
                .padding(.horizontal, 12)
            }
            .padding(.bottom, 16)
        }
        .background(BackgroundGrid())
    }
}

struct HomeCommand: View {
    let title: String
    let icon: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                Image(systemName: icon).font(.system(size: 25, weight: .bold)).foregroundStyle(Color.bbGold)
                Text(title).font(.system(size: 11, weight: .black, design: .rounded)).foregroundStyle(.white)
            }
            .frame(maxWidth: .infinity, minHeight: 76)
            .background(MetalPanel())
        }.buttonStyle(.plain)
    }
}

// MARK: - Deals

struct DealsView: View {
    @EnvironmentObject private var store: DealStore
    @State private var query = ""
    @State private var category = "All"
    private let categories = ["All", "Electronics", "Tools", "Outdoors", "Home"]

    var filtered: [Deal] {
        store.deals.filter { deal in
            (category == "All" || deal.category == category) &&
            (query.isEmpty || deal.title.localizedCaseInsensitiveContains(query) || deal.store.localizedCaseInsensitiveContains(query))
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            TopHeader(title: "DEALS", subtitle: "LIVE BOUNTY BOARD")
            SearchField(text: $query)
                .padding(.horizontal, 12).padding(.bottom, 10)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(categories, id: \.self) { c in
                        Chip(title: c, selected: category == c) { category = c }
                    }
                }.padding(.horizontal, 12)
            }
            .padding(.bottom, 8)

            ScrollView(showsIndicators: false) {
                LazyVStack(spacing: 8) {
                    ForEach(filtered) { deal in DealRow(deal: deal) }
                }
                .padding(.horizontal, 12).padding(.bottom, 14)
            }
        }
        .background(BackgroundGrid())
    }
}

struct DealRow: View {
    @EnvironmentObject private var store: DealStore
    let deal: Deal

    var body: some View {
        VStack(spacing: 10) {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.95))
                    Image(systemName: deal.symbol)
                        .font(.system(size: 30, weight: .semibold))
                        .foregroundStyle(Color.bbCharcoal)
                }
                .frame(width: 72, height: 66)

                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Text(deal.title).font(.system(size: 15, weight: .bold)).foregroundStyle(.white).lineLimit(1)
                        Spacer()
                        Button { store.toggleFavorite(deal) } label: {
                            Image(systemName: store.favorites.contains(deal.id) ? "heart.fill" : "heart")
                                .foregroundStyle(store.favorites.contains(deal.id) ? Color.red : Color.white.opacity(0.65))
                        }.buttonStyle(.plain)
                    }
                    Text(deal.store.uppercased()).font(.system(size: 10, weight: .black)).foregroundStyle(.white.opacity(0.52))
                    HStack(spacing: 7) {
                        DiscountPill(deal.discountPercent)
                        Text(deal.currentPrice, format: .currency(code: "USD")).font(.system(size: 18, weight: .black, design: .rounded)).foregroundStyle(Color.bbGoldBright)
                        Text(deal.originalPrice, format: .currency(code: "USD")).font(.caption).strikethrough().foregroundStyle(.white.opacity(0.45))
                    }
                    HStack(spacing: 4) {
                        Image(systemName: "star.fill").font(.caption2).foregroundStyle(Color.bbGold)
                        Text(String(format: "%.1f", deal.rating)).font(.caption2.bold())
                        Text("(\(deal.reviews))").font(.caption2).foregroundStyle(.white.opacity(0.5))
                    }.foregroundStyle(.white.opacity(0.82))
                }
            }
            HStack(spacing: 8) {
                Link(destination: deal.url) {
                    Label("VIEW DEAL", systemImage: "arrow.up.right.square.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(GoldButtonStyle())

                Button {
                    store.toggleTrack(deal)
                } label: {
                    Label(store.tracked.contains(deal.id) ? "TRACKING" : "TRACK", systemImage: store.tracked.contains(deal.id) ? "bell.fill" : "bell")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(DarkButtonStyle())
            }
        }
        .padding(11)
        .background(MetalPanel())
    }
}

// MARK: - Track

struct TrackView: View {
    @EnvironmentObject private var store: DealStore
    @State private var selectedID: UUID?

    private var selectedDeal: Deal {
        if let selectedID, let d = store.deals.first(where: { $0.id == selectedID }) { return d }
        return store.deals.first!
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 12) {
                TopHeader(title: "TRACK", subtitle: "PRICE HISTORY")

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(store.deals) { deal in
                            Button { selectedID = deal.id } label: {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(deal.title).font(.caption.bold()).lineLimit(1)
                                    Text(deal.currentPrice, format: .currency(code: "USD")).font(.caption2.bold()).foregroundStyle(Color.bbGold)
                                }
                                .foregroundStyle(.white)
                                .frame(width: 150, alignment: .leading)
                                .padding(10)
                                .background(RoundedRectangle(cornerRadius: 10).fill(selectedDeal.id == deal.id ? Color.bbGold.opacity(0.16) : Color.white.opacity(0.05)))
                                .overlay(RoundedRectangle(cornerRadius: 10).stroke(selectedDeal.id == deal.id ? Color.bbGold : Color.white.opacity(0.12)))
                            }.buttonStyle(.plain)
                        }
                    }.padding(.horizontal, 12)
                }

                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(selectedDeal.title).font(.headline.bold())
                            Text(selectedDeal.store).font(.caption).foregroundStyle(.white.opacity(0.55))
                        }
                        Spacer()
                        Text(selectedDeal.currentPrice, format: .currency(code: "USD"))
                            .font(.system(size: 24, weight: .black, design: .rounded)).foregroundStyle(Color.bbGoldBright)
                    }

                    PriceHistoryChart(points: selectedDeal.history)
                        .frame(height: 230)

                    HStack {
                        Label("Down \(selectedDeal.discountPercent)%", systemImage: "arrow.down.right")
                            .foregroundStyle(.green)
                        Spacer()
                        Text("Save \(selectedDeal.savings, format: .currency(code: "USD"))")
                            .font(.caption.bold()).foregroundStyle(Color.bbGold)
                    }

                    Button {
                        store.toggleTrack(selectedDeal)
                    } label: {
                        Label(store.tracked.contains(selectedDeal.id) ? "TRACKING THIS BOUNTY" : "TRACK THIS ITEM", systemImage: "bell.fill")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(GoldButtonStyle())
                }
                .padding(14)
                .background(MetalPanel())
                .padding(.horizontal, 12)

                HStack(spacing: 10) {
                    Button { store.event = .priceDrop(selectedDeal) } label: {
                        Label("PRICE DROP", systemImage: "arrow.down.circle.fill").frame(maxWidth: .infinity)
                    }.buttonStyle(DarkButtonStyle())
                    Button { store.event = .lost(selectedDeal) } label: {
                        Label("DEAL LOST", systemImage: "xmark.octagon.fill").frame(maxWidth: .infinity)
                    }.buttonStyle(DarkButtonStyle(accent: .red))
                }.padding(.horizontal, 12)
            }
            .padding(.bottom, 16)
        }
        .background(BackgroundGrid())
    }
}


struct PriceHistoryChart: View {
    let points: [PricePoint]

    var body: some View {
        Chart(points) { point in
            AreaMark(
                x: .value("Day", point.day),
                y: .value("Price", point.price)
            )
            .foregroundStyle(
                LinearGradient(
                    colors: [Color.bbBlue.opacity(0.55), Color.clear],
                    startPoint: .top,
                    endPoint: .bottom
                )
            )

            LineMark(
                x: .value("Day", point.day),
                y: .value("Price", point.price)
            )
            .foregroundStyle(Color.bbBlue)
            .lineStyle(StrokeStyle(lineWidth: 3, lineCap: .round, lineJoin: .round))

            PointMark(
                x: .value("Day", point.day),
                y: .value("Price", point.price)
            )
            .foregroundStyle(Color.bbBlue)
        }
        .chartYAxis { AxisMarks(position: .leading) }
    }
}

// MARK: - Tools

struct ToolsView: View {
    @EnvironmentObject private var store: DealStore
    @State private var scanner = false
    @State private var scannedCode = ""
    @State private var bulkQuery = ""
    @State private var showBulk = false
    @State private var showRules = false

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 10) {
                TopHeader(title: "TOOLS", subtitle: "BOUNTY GEAR")
                ToolRow(icon: "barcode.viewfinder", title: "Price Scanner", subtitle: scannedCode.isEmpty ? "Scan UPC / EAN / QR" : "Last: \(scannedCode)") { scanner = true }
                ToolToggle(icon: "bell.fill", title: "Deal Alerts", subtitle: "Notify on marked price drops", isOn: $store.alertsEnabled)
                ToolRow(icon: "magnifyingglass", title: "Bulk Search", subtitle: "Search multiple items") { showBulk = true }
                ToolRow(icon: "scalemass.fill", title: "Price Comparison", subtitle: "Compare store links") { store.selectedTab = .deals }
                ToolRow(icon: "shippingbox.fill", title: "Auto Buy (Rules)", subtitle: "Set your target price rules") { showRules = true }
                ToolRow(icon: "list.clipboard.fill", title: "Import Wish List", subtitle: "Paste or scan products") { showBulk = true }

                ShareLink(item: "Bounty Bot watch list: \(store.deals.filter { store.tracked.contains($0.id) }.map(\.title).joined(separator: ", "))") {
                    ToolStatic(icon: "square.and.arrow.up.fill", title: "Export / Share", subtitle: "Share tracked deals and lists")
                }
                .buttonStyle(.plain)

                SectionTitle("SCENE TEST BAY")
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                    SceneTestButton("DEAL LOST", color: .red) { store.event = .lost(store.deals[0]) }
                    SceneTestButton("NEW DEAL", color: .green) { store.event = .newDeal(store.deals[0]) }
                    SceneTestButton("HIGH NOON", color: .bbGold) { store.event = .highNoon }
                    SceneTestButton("TRAIN HUNT", color: .bbBlue) { store.event = .trainRun }
                }
                .padding(.horizontal, 12)
            }
            .padding(.bottom, 14)
        }
        .background(BackgroundGrid())
        .sheet(isPresented: $scanner) {
            BarcodeScannerSheet(code: $scannedCode)
                .presentationDetents([.large])
        }
        .sheet(isPresented: $showBulk) {
            NavigationStack {
                VStack(spacing: 16) {
                    Text("Paste item names, one per line.").foregroundStyle(.secondary)
                    TextEditor(text: $bulkQuery)
                        .font(.body.monospaced())
                        .padding(10)
                        .background(Color.secondary.opacity(0.10))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                    Button("Run Hunt") {
                        showBulk = false
                        store.runHunt()
                    }
                    .buttonStyle(GoldButtonStyle())
                }
                .padding()
                .navigationTitle("Bulk Search")
            }
        }
        .sheet(isPresented: $showRules) {
            NavigationStack {
                Form {
                    Toggle("Enable auto-buy rule", isOn: $store.autoBuyEnabled)
                    Section("Maximum target price") {
                        Slider(value: $store.autoBuyLimit, in: 25...1000, step: 5)
                        Text(store.autoBuyLimit, format: .currency(code: "USD"))
                    }
                    Section {
                        Text("Bounty Bot stores the rule locally. A purchase still opens the retailer for confirmation.")
                    }
                }
                .navigationTitle("Auto Buy Rules")
            }
        }
    }
}

struct ToolRow: View {
    let icon: String; let title: String; let subtitle: String; let action: () -> Void
    var body: some View {
        Button(action: action) { ToolStatic(icon: icon, title: title, subtitle: subtitle) }
            .buttonStyle(.plain).padding(.horizontal, 12)
    }
}

struct ToolToggle: View {
    let icon: String; let title: String; let subtitle: String; @Binding var isOn: Bool
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon).font(.title3.bold()).foregroundStyle(Color.bbGold).frame(width: 32)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.body.bold())
                Text(subtitle).font(.caption).foregroundStyle(.white.opacity(0.55))
            }
            Spacer(); Toggle("", isOn: $isOn).labelsHidden().tint(Color.bbGold)
        }
        .padding(13).background(MetalPanel()).padding(.horizontal, 12)
    }
}

struct ToolStatic: View {
    let icon: String; let title: String; let subtitle: String
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon).font(.title3.bold()).foregroundStyle(Color.bbGold).frame(width: 32)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.body.bold()).foregroundStyle(.white)
                Text(subtitle).font(.caption).foregroundStyle(.white.opacity(0.55))
            }
            Spacer(); Image(systemName: "chevron.right").foregroundStyle(Color.bbGold)
        }
        .padding(13).background(MetalPanel())
    }
}

// MARK: - More

struct MoreView: View {
    @EnvironmentObject private var store: DealStore
    @State private var sound = true
    @State private var cinematic = true

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 10) {
                TopHeader(title: "MORE", subtitle: "COMMAND CENTER")
                SceneCard(asset: "hero", height: 180).padding(.horizontal, 12)
                SettingsRow(icon: "gearshape.fill", title: "Settings", detail: "Native iOS")
                SettingsRow(icon: "link", title: "Connected Stores", detail: "Amazon • Walmart • eBay • Best Buy")
                SettingsRow(icon: "bell.badge.fill", title: "Notification Center", detail: store.alertsEnabled ? "Alerts armed" : "Alerts muted")
                SettingsRow(icon: "book.closed.fill", title: "Deal Log", detail: "\(store.tracked.count) tracked • \(store.favorites.count) favorites")
                SettingsRow(icon: "chart.bar.fill", title: "Statistics", detail: "Best sample saving: 35%")
                HStack { Text("Cinematic animations"); Spacer(); Toggle("", isOn: $cinematic).labelsHidden().tint(Color.bbGold) }
                    .padding(13).background(MetalPanel()).padding(.horizontal, 12)
                HStack { Text("Haptic / sound cues"); Spacer(); Toggle("", isOn: $sound).labelsHidden().tint(Color.bbGold) }
                    .padding(13).background(MetalPanel()).padding(.horizontal, 12)
                SettingsRow(icon: "info.circle.fill", title: "About Bounty Bot", detail: "v1.0.0 • Native SwiftUI")
            }
            .padding(.bottom, 14)
        }
        .background(BackgroundGrid())
    }
}

struct SettingsRow: View {
    let icon: String; let title: String; let detail: String
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon).font(.title3.bold()).foregroundStyle(Color.bbGold).frame(width: 30)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.body.bold())
                Text(detail).font(.caption).foregroundStyle(.white.opacity(0.55)).lineLimit(1)
            }
            Spacer(); Image(systemName: "chevron.right").foregroundStyle(Color.bbGold)
        }
        .padding(13).background(MetalPanel()).padding(.horizontal, 12)
    }
}

// MARK: - Cinematic events

struct DealEventOverlay: View {
    let event: DealEvent
    let dismiss: () -> Void
    @State private var appear = false
    @State private var barsDropped = false
    @State private var glareX: CGFloat = -1
    @State private var trainShift: CGFloat = 0
    @State private var recoil: CGFloat = 1
    @State private var sparks = false

    var body: some View {
        ZStack {
            Color.black.opacity(0.96).ignoresSafeArea()
            SceneBackdrop(asset: event.assetName)

            switch event {
            case .lost(let deal):
                lostScene(deal)
            case .newDeal(let deal):
                newDealScene(deal)
            case .priceDrop(let deal):
                priceDropScene(deal)
            case .secured(let deal):
                securedScene(deal)
            case .highNoon:
                highNoonScene
            case .trainRun:
                trainScene
            }

            VStack {
                HStack { Spacer(); Button(action: dismiss) { CircleIcon("xmark") } }
                    .padding(.horizontal, 16).padding(.top, 8)
                Spacer()
            }
        }
        .onAppear { startAnimation() }
        .onTapGesture { if event != .trainRun { dismiss() } }
    }

    @ViewBuilder private func lostScene(_ deal: Deal) -> some View {
        ZStack {
            Color.red.opacity(appear ? 0.18 : 0).ignoresSafeArea().blendMode(.screen)
            VStack(spacing: 8) {
                Spacer()
                Text("DEAL LOST").font(.system(size: 42, weight: .black, design: .rounded)).foregroundStyle(.red)
                    .shadow(color: .red, radius: 14).scaleEffect(appear ? 1 : 1.4)
                Text("PRICE INCREASED").font(.headline.weight(.black)).tracking(2).foregroundStyle(.white)
                Text(deal.title).font(.headline).foregroundStyle(.white.opacity(0.8))
                HStack(spacing: 12) {
                    EventStat("WAS", value: deal.currentPrice, color: .white)
                    EventStat("NOW", value: deal.currentPrice + 50, color: .red)
                }
                .padding(.bottom, 30)
            }
            JailBars(dropped: barsDropped)
        }
    }

    @ViewBuilder private func newDealScene(_ deal: Deal) -> some View {
        VStack {
            Spacer()
            VStack(spacing: 10) {
                Text("NEW DEAL").font(.system(size: 44, weight: .black, design: .rounded)).foregroundStyle(.green)
                    .shadow(color: .green, radius: appear ? 26 : 4)
                Text("MATCH FOUND").font(.headline.weight(.black)).tracking(2)
                Text(deal.title).font(.title3.bold())
                Text(deal.currentPrice, format: .currency(code: "USD"))
                    .font(.system(size: 32, weight: .black, design: .rounded)).foregroundStyle(Color.bbGoldBright)
                DiscountPill(deal.discountPercent)
            }
            .padding(22)
            .background(.black.opacity(0.78))
            .clipShape(RoundedRectangle(cornerRadius: 22))
            .overlay(RoundedRectangle(cornerRadius: 22).stroke(Color.green, lineWidth: 2))
            .scaleEffect(appear ? 1 : 0.6)
            .opacity(appear ? 1 : 0)
            Spacer().frame(height: 48)
        }.padding(.horizontal, 18)
    }

    @ViewBuilder private func priceDropScene(_ deal: Deal) -> some View {
        VStack {
            Spacer()
            Text("PRICE DROP").font(.system(size: 42, weight: .black, design: .rounded)).foregroundStyle(Color.bbGoldBright)
                .shadow(color: Color.bbGold, radius: 20)
            Text(deal.title).font(.headline).padding(.top, 4)
            HStack(alignment: .firstTextBaseline, spacing: 10) {
                Text(deal.originalPrice, format: .currency(code: "USD")).strikethrough().foregroundStyle(.white.opacity(0.5))
                Text(deal.currentPrice, format: .currency(code: "USD")).font(.system(size: 34, weight: .black)).foregroundStyle(.green)
            }
            Image(systemName: "arrow.down").font(.system(size: 54, weight: .black)).foregroundStyle(.green)
                .offset(y: appear ? 0 : -80).opacity(appear ? 1 : 0)
            Spacer().frame(height: 58)
        }
    }

    @ViewBuilder private func securedScene(_ deal: Deal) -> some View {
        VStack {
            Spacer()
            Image(systemName: "checkmark.seal.fill").font(.system(size: 74)).foregroundStyle(Color.bbBlue)
                .shadow(color: Color.bbBlue, radius: 28).scaleEffect(appear ? 1 : 0.2)
            Text("DEAL SECURED").font(.system(size: 38, weight: .black, design: .rounded)).foregroundStyle(.white)
            Text("ADDED TO YOUR WATCHLIST").font(.caption.weight(.black)).tracking(1.5).foregroundStyle(Color.bbBlue)
            Text(deal.title).font(.headline).padding(.top, 4)
            Spacer().frame(height: 58)
        }
    }

    private var highNoonScene: some View {
        ZStack {
            Rectangle()
                .fill(LinearGradient(colors: [Color.clear, Color.white.opacity(0.92), Color.bbGold.opacity(0.15), Color.clear], startPoint: .leading, endPoint: .trailing))
                .frame(width: 70)
                .blur(radius: 6)
                .offset(x: glareX * 330)
                .blendMode(.screen)
            VStack {
                Spacer()
                Text("HIGH NOON").font(.system(size: 42, weight: .black, design: .rounded)).foregroundStyle(Color.bbGoldBright)
                    .shadow(color: Color.bbGold, radius: 18)
                Text("COMPARE • AIM • TAKE THE BEST PRICE").font(.caption.weight(.black)).tracking(1.6)
                Spacer().frame(height: 54)
            }
        }
    }

    private var trainScene: some View {
        ZStack {
            ExactPNG("train")
                .scaledToFill()
                .scaleEffect(1.10)
                .offset(x: trainShift)
                .blur(radius: 0.2)
                .ignoresSafeArea()
            LinearGradient(colors: [Color.black.opacity(0.05), Color.black.opacity(0.25), Color.black.opacity(0.85)], startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            Sparks(active: sparks)
            VStack {
                Spacer()
                Text("HUNT IN MOTION").font(.system(size: 38, weight: .black, design: .rounded)).foregroundStyle(Color.bbGoldBright)
                    .shadow(color: Color.bbGold, radius: 20)
                Text("SCANNING STORES • COMPARING PRICES • CHECKING STOCK")
                    .font(.system(size: 10, weight: .black)).tracking(1.2).multilineTextAlignment(.center)
                ProgressView().tint(Color.bbGold).scaleEffect(1.3).padding(.top, 12)
                Spacer().frame(height: 56)
            }
        }
    }

    private func startAnimation() {
        withAnimation(.spring(response: 0.55, dampingFraction: 0.7)) { appear = true }
        switch event {
        case .lost:
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.18) {
                withAnimation(.interpolatingSpring(stiffness: 170, damping: 13)) { barsDropped = true }
                UINotificationFeedbackGenerator().notificationOccurred(.error)
            }
        case .newDeal, .priceDrop, .secured:
            UINotificationFeedbackGenerator().notificationOccurred(.success)
        case .highNoon:
            glareX = -1.2
            withAnimation(.easeInOut(duration: 1.25).repeatForever(autoreverses: false)) { glareX = 1.3 }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.42) {
                UIImpactFeedbackGenerator(style: .heavy).impactOccurred(); recoil = 0.97
                withAnimation(.spring(response: 0.22, dampingFraction: 0.55)) { recoil = 1 }
            }
        case .trainRun:
            trainShift = -30; sparks = true
            withAnimation(.linear(duration: 2.15)) { trainShift = 30 }
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        }
    }
}

struct JailBars: View {
    let dropped: Bool
    var body: some View {
        GeometryReader { geo in
            let count = 7
            HStack(spacing: geo.size.width / CGFloat(count * 2)) {
                ForEach(0..<count, id: \.self) { i in
                    RoundedRectangle(cornerRadius: 6)
                        .fill(LinearGradient(colors: [.white.opacity(0.9), .gray, .black, .gray], startPoint: .leading, endPoint: .trailing))
                        .frame(width: 22, height: geo.size.height * 1.15)
                        .overlay(RoundedRectangle(cornerRadius: 6).stroke(Color.white.opacity(0.3)))
                        .offset(y: dropped ? 0 : -geo.size.height * 1.25 - CGFloat(i * 30))
                        .animation(.interpolatingSpring(stiffness: 155, damping: 14).delay(Double(i) * 0.035), value: dropped)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            VStack { Spacer(); Rectangle().fill(Color.black.opacity(0.85)).frame(height: 38).overlay(Rectangle().stroke(Color.red.opacity(0.6), lineWidth: 2)) }
        }.ignoresSafeArea().allowsHitTesting(false)
    }
}

struct Sparks: View {
    let active: Bool
    var body: some View {
        TimelineView(.animation) { context in
            Canvas { ctx, size in
                guard active else { return }
                let t = context.date.timeIntervalSinceReferenceDate
                for i in 0..<30 {
                    let seed = Double(i) * 0.61803398875
                    let x = CGFloat(seed.truncatingRemainder(dividingBy: 1.0)) * size.width
                    let travel = Double(size.height + 80)
                    let rawPhase = (t * (45 + Double(i % 7) * 8) + Double(i * 41)).truncatingRemainder(dividingBy: travel)
                    let phase = CGFloat(rawPhase)
                    let y = size.height - phase
                    let rect = CGRect(x: x, y: y, width: CGFloat(2 + (i % 3)), height: CGFloat(8 + (i % 7)))
                    ctx.fill(Path(roundedRect: rect, cornerRadius: 2), with: .color(Color.bbGold.opacity(0.7)))
                }
            }
        }.blendMode(.screen).allowsHitTesting(false)
    }
}

struct EventStat: View {
    let label: String; let value: Double; let color: Color
    init(_ label: String, value: Double, color: Color) { self.label = label; self.value = value; self.color = color }
    var body: some View {
        VStack(spacing: 3) {
            Text(label).font(.caption2.weight(.black)).foregroundStyle(.white.opacity(0.55))
            Text(value, format: .currency(code: "USD")).font(.title3.weight(.black)).foregroundStyle(color)
        }
        .padding(.horizontal, 16).padding(.vertical, 10)
        .background(Color.black.opacity(0.66)).clipShape(RoundedRectangle(cornerRadius: 10))
    }
}

// MARK: - Native barcode scanner

struct BarcodeScannerSheet: View {
    @Binding var code: String
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()
                BarcodeScannerView { value in
                    code = value
                    UINotificationFeedbackGenerator().notificationOccurred(.success)
                    dismiss()
                }
                VStack {
                    Spacer()
                    RoundedRectangle(cornerRadius: 18)
                        .stroke(Color.bbGold, style: StrokeStyle(lineWidth: 3, dash: [14,8]))
                        .frame(height: 180).padding(.horizontal, 34)
                    Text("Center a UPC, EAN, or QR code inside the frame")
                        .font(.caption.bold()).foregroundStyle(.white).padding(.top, 12)
                    Spacer()
                }.allowsHitTesting(false)
            }
            .navigationTitle("Price Scanner")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("Close") { dismiss() } } }
        }
    }
}

struct BarcodeScannerView: UIViewControllerRepresentable {
    let onCode: (String) -> Void
    func makeUIViewController(context: Context) -> ScannerViewController {
        let vc = ScannerViewController(); vc.onCode = onCode; return vc
    }
    func updateUIViewController(_ uiViewController: ScannerViewController, context: Context) {}
}

final class ScannerViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    var onCode: ((String) -> Void)?
    private let session = AVCaptureSession()
    private var preview: AVCaptureVideoPreviewLayer?
    private var delivered = false

    override func viewDidLoad() {
        super.viewDidLoad(); view.backgroundColor = .black
        AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
            guard granted else { return }
            DispatchQueue.main.async { self?.configure() }
        }
    }

    private func configure() {
        guard let device = AVCaptureDevice.default(for: .video),
              let input = try? AVCaptureDeviceInput(device: device), session.canAddInput(input) else { return }
        session.addInput(input)
        let output = AVCaptureMetadataOutput()
        guard session.canAddOutput(output) else { return }
        session.addOutput(output)
        output.setMetadataObjectsDelegate(self, queue: .main)
        output.metadataObjectTypes = [.ean8, .ean13, .upce, .qr, .code128, .code39]
        let layer = AVCaptureVideoPreviewLayer(session: session)
        layer.videoGravity = .resizeAspectFill; layer.frame = view.bounds
        view.layer.insertSublayer(layer, at: 0); preview = layer
        DispatchQueue.global(qos: .userInitiated).async { self.session.startRunning() }
    }

    override func viewDidLayoutSubviews() { super.viewDidLayoutSubviews(); preview?.frame = view.bounds }
    override func viewWillDisappear(_ animated: Bool) { super.viewWillDisappear(animated); session.stopRunning() }

    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        guard !delivered, let obj = metadataObjects.first as? AVMetadataMachineReadableCodeObject, let value = obj.stringValue else { return }
        delivered = true; session.stopRunning(); onCode?(value)
    }
}

// MARK: - Shared UI

struct TopHeader: View {
    let title: String; let subtitle: String
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 0) {
                Text(title).font(.system(size: 24, weight: .black, design: .rounded)).foregroundStyle(Color.bbGoldBright)
                Text(subtitle).font(.system(size: 9, weight: .black)).tracking(2.2).foregroundStyle(.white.opacity(0.55))
            }
            Spacer()
            ZStack {
                Circle().stroke(Color.bbGold.opacity(0.7), lineWidth: 2).frame(width: 42, height: 42)
                Image(systemName: "scope").foregroundStyle(Color.bbGold).font(.title3.bold())
            }
        }
        .padding(.horizontal, 14).padding(.top, 12).padding(.bottom, 10)
    }
}

struct SearchField: View {
    @Binding var text: String
    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass").foregroundStyle(Color.bbGold)
            TextField("Find deals, products, brands…", text: $text).textInputAutocapitalization(.never).autocorrectionDisabled()
            Image(systemName: "slider.horizontal.3").foregroundStyle(.white.opacity(0.6))
        }
        .padding(.horizontal, 12).frame(height: 46)
        .background(Color.black.opacity(0.58)).clipShape(RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.bbGold.opacity(0.45)))
    }
}

struct SectionTitle: View {
    let text: String
    init(_ text: String) { self.text = text }
    var body: some View {
        HStack {
            Text(text).font(.system(size: 13, weight: .black, design: .rounded)).tracking(1.2).foregroundStyle(Color.bbGold)
            Rectangle().fill(Color.bbGold.opacity(0.30)).frame(height: 1)
        }.padding(.horizontal, 14).padding(.top, 4)
    }
}

struct Chip: View {
    let title: String; let selected: Bool; let action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(title.uppercased()).font(.system(size: 10, weight: .black))
                .padding(.horizontal, 14).padding(.vertical, 8)
                .foregroundStyle(selected ? .black : .white.opacity(0.75))
                .background(selected ? Color.bbGold : Color.white.opacity(0.06))
                .clipShape(Capsule())
                .overlay(Capsule().stroke(selected ? Color.bbGoldBright : Color.white.opacity(0.12)))
        }.buttonStyle(.plain)
    }
}

struct DiscountPill: View {
    let value: Int
    init(_ value: Int) { self.value = value }
    var body: some View {
        Text("-\(value)%").font(.system(size: 10, weight: .black)).foregroundStyle(.white)
            .padding(.horizontal, 6).padding(.vertical, 3).background(Color.green).clipShape(Capsule())
    }
}

struct SceneTestButton: View {
    let title: String; let color: Color; let action: () -> Void
    init(_ title: String, color: Color, action: @escaping () -> Void) { self.title = title; self.color = color; self.action = action }
    var body: some View {
        Button(action: action) {
            Text(title).font(.system(size: 11, weight: .black)).foregroundStyle(color)
                .frame(maxWidth: .infinity).padding(.vertical, 13)
                .background(Color.black.opacity(0.7)).clipShape(RoundedRectangle(cornerRadius: 10))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(color.opacity(0.75)))
        }.buttonStyle(.plain)
    }
}

struct CircleIcon: View {
    let systemName: String
    init(_ systemName: String) { self.systemName = systemName }
    var body: some View {
        Image(systemName: systemName).font(.system(size: 14, weight: .black)).foregroundStyle(Color.bbGold)
            .frame(width: 38, height: 38).background(.black.opacity(0.72)).clipShape(Circle())
            .overlay(Circle().stroke(Color.bbGold.opacity(0.75)))
    }
}

struct SceneCard: View {
    let asset: String; let height: CGFloat
    var body: some View {
        ZStack {
            ExactPNG(asset).scaledToFill().frame(maxWidth: .infinity).frame(height: height).clipped()
            LinearGradient(colors: [.clear, .black.opacity(0.05), .black.opacity(0.78)], startPoint: .top, endPoint: .bottom)
        }
        .frame(height: height)
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.bbGold.opacity(0.58), lineWidth: 1.4))
        .shadow(color: Color.bbGold.opacity(0.16), radius: 18)
    }
}

struct SceneBackdrop: View {
    let asset: String
    var body: some View {
        ZStack {
            ExactPNG(asset).scaledToFill().blur(radius: 18).scaleEffect(1.22).ignoresSafeArea().opacity(0.58)
            Color.black.opacity(0.26).ignoresSafeArea()
            ExactPNG(asset).scaledToFit().padding(.horizontal, 4)
                .shadow(color: .black, radius: 30)
        }
    }
}

struct ExactPNG: View {
    let name: String
    init(_ name: String) { self.name = name }

    private var image: UIImage? {
        if let named = UIImage(named: name) { return named }
        if let url = Bundle.main.url(forResource: name, withExtension: "png"),
           let file = UIImage(contentsOfFile: url.path) { return file }
        if let url = Bundle.main.url(forResource: name, withExtension: "png", subdirectory: "Resources"),
           let file = UIImage(contentsOfFile: url.path) { return file }
        return nil
    }

    @ViewBuilder
    var body: some View {
        if let image {
            Image(uiImage: image)
                .resizable()
                .interpolation(.high)
        } else {
            ZStack {
                Color.black
                Image(systemName: "photo")
                    .foregroundStyle(Color.bbGold)
            }
        }
    }
}

struct MetalPanel: View {
    var body: some View {
        RoundedRectangle(cornerRadius: 14)
            .fill(LinearGradient(colors: [Color(red: 0.08, green: 0.09, blue: 0.10), Color(red: 0.015, green: 0.018, blue: 0.02)], startPoint: .topLeading, endPoint: .bottomTrailing))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(LinearGradient(colors: [Color.bbGold.opacity(0.68), Color.white.opacity(0.10), Color.bbGold.opacity(0.30)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1.1))
            .shadow(color: .black.opacity(0.45), radius: 8, y: 4)
    }
}

struct BackgroundGrid: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.025, green: 0.025, blue: 0.03), .black], startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            Canvas { ctx, size in
                let step: CGFloat = 26
                var path = Path()
                stride(from: 0, through: size.width, by: step).forEach { x in path.move(to: CGPoint(x: x, y: 0)); path.addLine(to: CGPoint(x: x, y: size.height)) }
                stride(from: 0, through: size.height, by: step).forEach { y in path.move(to: CGPoint(x: 0, y: y)); path.addLine(to: CGPoint(x: size.width, y: y)) }
                ctx.stroke(path, with: .color(Color.bbGold.opacity(0.025)), lineWidth: 0.6)
            }.ignoresSafeArea()
        }
    }
}

struct GoldButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 11, weight: .black))
            .foregroundStyle(.black)
            .padding(.vertical, 10)
            .background(LinearGradient(colors: [Color.bbGoldBright, Color.bbGold], startPoint: .top, endPoint: .bottom))
            .clipShape(RoundedRectangle(cornerRadius: 9))
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
    }
}

struct DarkButtonStyle: ButtonStyle {
    var accent: Color = .bbGold
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 11, weight: .black))
            .foregroundStyle(accent)
            .padding(.vertical, 10)
            .background(Color.black.opacity(0.65))
            .clipShape(RoundedRectangle(cornerRadius: 9))
            .overlay(RoundedRectangle(cornerRadius: 9).stroke(accent.opacity(0.65)))
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
    }
}

extension Font.Weight { static let blackish = Font.Weight.black }
extension View {
    func blackText() -> some View { self.fontWeight(.black) }
}

extension Color {
    static let bbBlack = Color(red: 0.008, green: 0.009, blue: 0.012)
    static let bbCharcoal = Color(red: 0.08, green: 0.09, blue: 0.10)
    static let bbGold = Color(red: 0.94, green: 0.58, blue: 0.05)
    static let bbGoldBright = Color(red: 1.0, green: 0.76, blue: 0.19)
    static let bbBlue = Color(red: 0.0, green: 0.68, blue: 1.0)
}

private extension Text {
    var black: Text { fontWeight(.black) }
}
