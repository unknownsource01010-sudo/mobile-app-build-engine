import Foundation

@MainActor
final class AccountStore: ObservableObject {
    @Published var accounts: [AccountRecord] = [] {
        didSet { save() }
    }

    private let storeURL: URL

    init() {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        storeURL = base.appendingPathComponent("autozen-accounts.json")
        load()
    }

    func upsert(_ account: AccountRecord) {
        if let index = accounts.firstIndex(where: { $0.id == account.id }) {
            accounts[index] = account
        } else {
            accounts.append(account)
        }
    }

    func delete(_ account: AccountRecord) {
        accounts.removeAll { $0.id == account.id }
    }

    func toggleReady(accountID: UUID, service: ServiceName) {
        guard let i = accounts.firstIndex(where: { $0.id == accountID }) else { return }
        var state = accounts[i].services[service.rawValue] ?? ServiceState()
        state.ready.toggle()
        accounts[i].services[service.rawValue] = state
    }

    func markOpened(accountID: UUID, service: ServiceName) {
        guard let i = accounts.firstIndex(where: { $0.id == accountID }) else { return }
        var state = accounts[i].services[service.rawValue] ?? ServiceState()
        state.lastOpen = Date()
        accounts[i].services[service.rawValue] = state
    }

    func csvURL() throws -> URL {
        var rows = ["Identity,Email,Service,Username,Ready,Amount USD,Billing,Next Date,Last Open,Contents Date,Contents,Recovery File,Notes"]
        for account in accounts {
            for service in ServiceName.allCases {
                let state = account.state(for: service)
                let values = [account.label, account.email, service.title, state.username ?? account.email,
                              state.ready ? "ready" : "needs-work", state.amount.map { String($0) } ?? "",
                              state.billing ?? "", state.renewal?.ISO8601Format() ?? "", state.lastOpen?.ISO8601Format() ?? "",
                              state.inventoryDate?.ISO8601Format() ?? "", state.inventory ?? "",
                              account.recoveryFileName, account.notes]
                rows.append(values.map(csvCell).joined(separator: ","))
            }
        }

        let url = FileManager.default.temporaryDirectory.appendingPathComponent("AutoZen-Accounts.csv")
        try rows.joined(separator: "\n").write(to: url, atomically: true, encoding: .utf8)
        return url
    }

    func backupURL(passphrase: String) throws -> URL {
        guard passphrase.count >= 12 else {
            throw NSError(domain: "AutoZen", code: 10, userInfo: [NSLocalizedDescriptionKey: "Use at least 12 characters for the backup passphrase."])
        }
        let data = try JSONEncoder.pretty.encode(accounts)
        let payload = try VaultCrypto.encrypt(String(decoding: data, as: UTF8.self), passphrase: passphrase)
        let encrypted = try JSONEncoder.pretty.encode(payload)
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("AutoZen-Encrypted-Vault-Backup.json")
        try encrypted.write(to: url, options: [.atomic, .completeFileProtection])
        return url
    }

    func restore(_ data: Data, passphrase: String) throws {
        let records: [AccountRecord]
        if let legacy = try? JSONDecoder().decode([AccountRecord].self, from: data) {
            records = legacy
        } else {
            let payload = try JSONDecoder().decode(VaultPayload.self, from: data)
            let clear = try VaultCrypto.decrypt(payload, passphrase: passphrase)
            records = try JSONDecoder().decode([AccountRecord].self, from: Data(clear.utf8))
        }
        guard Set(records.map(\.id)).count == records.count else {
            throw NSError(domain: "AutoZen", code: 11, userInfo: [NSLocalizedDescriptionKey: "Backup contains duplicate identity IDs."])
        }
        var merged = accounts
        for record in records {
            if let index = merged.firstIndex(where: { $0.id == record.id }) { merged[index] = record }
            else { merged.append(record) }
        }
        accounts = merged
    }

    private func csvCell(_ value: String) -> String {
        "\"" + value.replacingOccurrences(of: "\"", with: "\"\"") + "\""
    }

    private func load() {
        guard
            let data = try? Data(contentsOf: storeURL),
            let decoded = try? JSONDecoder().decode([AccountRecord].self, from: data)
        else { return }
        accounts = decoded
    }

    private func save() {
        guard let data = try? JSONEncoder.pretty.encode(accounts) else { return }
        try? data.write(to: storeURL, options: [.atomic, .completeFileProtection])
    }
}

private extension JSONEncoder {
    static var pretty: JSONEncoder {
        let e = JSONEncoder()
        e.outputFormatting = [.prettyPrinted, .sortedKeys]
        return e
    }
}
