import SwiftUI

struct ServiceEditTarget: Identifiable {
    var id: String { account.id.uuidString + service.rawValue }
    let account: AccountRecord
    let service: ServiceName
}

struct ServiceEditor: View {
    @EnvironmentObject var store: AccountStore
    @Environment(\.dismiss) private var dismiss
    let target: ServiceEditTarget
    @State private var username: String
    @State private var amount: String
    @State private var billing: String
    @State private var hasRenewal: Bool
    @State private var renewal: Date
    @State private var password = ""
    @State private var passphrase = ""
    @State private var error = ""
    @State private var inventory: String

    init(target: ServiceEditTarget) {
        self.target = target
        let state = target.account.state(for: target.service)
        _username = State(initialValue: state.username ?? target.account.email)
        _amount = State(initialValue: state.amount.map { String($0) } ?? "")
        _billing = State(initialValue: state.billing ?? "monthly")
        _hasRenewal = State(initialValue: state.renewal != nil)
        _renewal = State(initialValue: state.renewal ?? Date())
        _inventory = State(initialValue: state.inventory ?? "")
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("\(target.account.label) · \(target.service.title)") {
                    TextField("Username / email", text: $username).textInputAutocapitalization(.never).autocorrectionDisabled().textContentType(.username)
                    SecureField("New password (optional)", text: $password).textContentType(.newPassword)
                    SecureField("Vault passphrase", text: $passphrase)
                    Text("Saved passwords stay encrypted in AutoZen. Use Copy password when signing in. Your vault passphrase is never stored.").font(.footnote).foregroundStyle(.secondary)
                }
                Section("Cost and date") {
                    TextField("USD amount (blank = unknown)", text: $amount).keyboardType(.decimalPad)
                    Picker("Billing", selection: $billing) {
                        Text("Monthly").tag("monthly")
                        Text("Yearly").tag("yearly")
                        Text("One time").tag("one-time")
                        Text("Free").tag("free")
                    }
                    Toggle("Track next date", isOn: $hasRenewal)
                    if hasRenewal { DatePicker("Next payment / review", selection: $renewal, displayedComponents: .date) }
                }
                Section("What's inside") {
                    TextEditor(text: $inventory).frame(minHeight: 140)
                    Text("Add a summary, or open the account and tap Save contents on its file/repository listing. This records the visible page, not a complete account audit.").font(.footnote).foregroundStyle(.secondary)
                }
                if !error.isEmpty { Text(error).foregroundStyle(.red) }
            }
            .navigationTitle("Service details").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Save") { save() } }
            }
        }
    }

    private func save() {
        do {
            var account = store.accounts.first { $0.id == target.account.id } ?? target.account
            var state = account.state(for: target.service)
            let normalized = amount.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: ",", with: "")
            if !normalized.isEmpty && (Double(normalized) == nil || (Double(normalized) ?? -1) < 0) {
                error = "Enter a valid nonnegative amount."; return
            }
            state.username = username.trimmingCharacters(in: .whitespacesAndNewlines)
            state.amount = billing == "free" ? 0 : Double(normalized)
            state.billing = billing
            state.renewal = hasRenewal ? renewal : nil
            if state.inventory != inventory { state.inventory = inventory; state.inventoryDate = Date() }
            if !password.isEmpty {
                guard !passphrase.isEmpty else { error = "Enter your vault passphrase to encrypt the password."; return }
                state.secret = try VaultCrypto.encrypt(password, passphrase: passphrase)
            }
            account.services[target.service.rawValue] = state
            store.upsert(account)
            dismiss()
        } catch { self.error = error.localizedDescription }
    }
}
