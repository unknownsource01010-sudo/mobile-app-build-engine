import Foundation

enum ServiceName: String, Codable, CaseIterable, Identifiable {
    case gmail
    case github
    case mega

    var id: String { rawValue }

    var title: String {
        switch self {
        case .gmail: return "Gmail"
        case .github: return "GitHub"
        case .mega: return "MEGA"
        }
    }

    var loginURL: URL {
        switch self {
        case .gmail: return URL(string: "https://mail.google.com/")!
        case .github: return URL(string: "https://github.com/login")!
        case .mega: return URL(string: "https://mega.nz/login")!
        }
    }

    var createURL: URL {
        switch self {
        case .gmail: return URL(string: "https://accounts.google.com/signup")!
        case .github: return URL(string: "https://github.com/signup")!
        case .mega: return URL(string: "https://mega.nz/register")!
        }
    }
}

struct ServiceState: Codable, Hashable {
    var ready = false
    var lastOpen: Date?
    var username: String?
    var amount: Double?
    var billing: String?
    var renewal: Date?
    var secret: VaultPayload?
    var inventory: String?
    var inventoryDate: Date?
    var inventoryURL: String?
}

struct VaultPayload: Codable, Hashable {
    var salt: String
    var combined: String
}

struct AccountRecord: Identifiable, Codable, Hashable {
    var id = UUID()
    var label = ""
    var email = ""
    var createdAt = Date()
    var recoveryFileName = ""
    var recoveryFolderNote = ""
    var notes = ""
    var services: [String: ServiceState] = [:]
    var secret: VaultPayload?

    func state(for service: ServiceName) -> ServiceState {
        services[service.rawValue] ?? ServiceState()
    }
}
