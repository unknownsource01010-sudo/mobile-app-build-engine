import Foundation

enum AccountSummary {
    static func monthlyCost(_ accounts: [AccountRecord]) -> Double {
        accounts.reduce(0) { total, account in
            total + ServiceName.allCases.reduce(0) { sum, service in
                let state = account.state(for: service)
                switch state.billing {
                case "monthly": return sum + (state.amount ?? 0)
                case "yearly": return sum + (state.amount ?? 0) / 12
                default: return sum
                }
            }
        }
    }
}
