import Foundation
import CryptoKit
import Security

enum VaultCrypto {
    static func encrypt(_ plaintext: String, passphrase: String) throws -> VaultPayload {
        let salt = randomData(count: 16)
        let key = deriveKey(passphrase: passphrase, salt: salt)
        let box = try AES.GCM.seal(Data(plaintext.utf8), using: key)
        guard let combined = box.combined else {
            throw NSError(domain: "AutoZenVault", code: 1, userInfo: [NSLocalizedDescriptionKey: "Could not create encrypted vault payload."])
        }
        return VaultPayload(
            salt: salt.base64EncodedString(),
            combined: combined.base64EncodedString()
        )
    }

    static func decrypt(_ payload: VaultPayload, passphrase: String) throws -> String {
        guard
            let salt = Data(base64Encoded: payload.salt),
            let combined = Data(base64Encoded: payload.combined)
        else {
            throw NSError(domain: "AutoZenVault", code: 2, userInfo: [NSLocalizedDescriptionKey: "Vault data is invalid."])
        }

        let key = deriveKey(passphrase: passphrase, salt: salt)
        let box = try AES.GCM.SealedBox(combined: combined)
        let clear = try AES.GCM.open(box, using: key)
        return String(decoding: clear, as: UTF8.self)
    }

    private static func deriveKey(passphrase: String, salt: Data) -> SymmetricKey {
        var material = Data(passphrase.utf8)
        material.append(salt)

        var digest = Data(SHA256.hash(data: material))
        for _ in 0..<60_000 {
            var round = Data()
            round.append(digest)
            round.append(salt)
            digest = Data(SHA256.hash(data: round))
        }

        return SymmetricKey(data: digest)
    }

    private static func randomData(count: Int) -> Data {
        var data = Data(count: count)
        data.withUnsafeMutableBytes { ptr in
            guard let base = ptr.baseAddress else { return }
            _ = SecRandomCopyBytes(kSecRandomDefault, count, base)
        }
        return data
    }
}

