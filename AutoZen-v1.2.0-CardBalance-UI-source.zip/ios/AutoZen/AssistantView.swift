import SwiftUI

enum AccountGuide {
    static func checklist(_ accounts: [AccountRecord]) -> String {
        guard !accounts.isEmpty else { return "Add an identity with +, then expand it. Create or sign in to Gmail, GitHub and MEGA. Complete each site's verification, then mark that service ready. Store a password using your vault passphrase and record your recovery file. Export an encrypted backup when finished." }
        return accounts.map { account in
            let pending = ServiceName.allCases.filter { !account.state(for: $0).ready }.map(\.title)
            var lines = [account.label, pending.isEmpty ? "All services manually marked ready." : "Finish sign-in/verification: " + pending.joined(separator: ", ")]
            if account.secret == nil { lines.append("No encrypted password saved.") }
            if account.recoveryFileName.isEmpty { lines.append("Record a recovery-file location.") }
            return lines.joined(separator: "\n")
        }.joined(separator: "\n\n")
    }
}

struct AssistantView: View {
    @EnvironmentObject var store: AccountStore
    @Environment(\.dismiss) private var dismiss
    @AppStorage("autozen.ai.endpoint") private var endpoint = ""
    @AppStorage("autozen.ai.model") private var model = "llama3.2:3b"
    @State private var prompt = "Help me finish setting up my accounts and recovery plan."
    @State private var answer = ""
    @State private var error = ""
    @State private var busy = false
    @State private var includeStatus = false
    @State private var task: Task<Void, Never>?

    var body: some View {
        NavigationStack {
            Form {
                Section("Offline checklist") {
                    Text(AccountGuide.checklist(store.accounts)).textSelection(.enabled)
                }
                Section("Local AI") {
                    TextField("Ollama host: http://192.168.1.50:11434", text: $endpoint)
                        .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                    TextField("Installed model", text: $model).textInputAutocapitalization(.never).autocorrectionDisabled()
                    Text("Connect to Ollama on your computer. The model runs there; the offline checklist runs on your iPhone.").font(.footnote).foregroundStyle(.secondary)
                    TextEditor(text: $prompt).frame(minHeight: 85)
                    Toggle("Include service completion counts", isOn: $includeStatus)
                    Text("Only your prompt and optional counts are sent. Passwords, emails, identity names and recovery notes are not included automatically.").font(.footnote).foregroundStyle(.secondary)
                    Button(busy ? "Asking…" : "Ask AI") { ask() }.disabled(busy || prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    if busy { Button("Cancel") { task?.cancel(); busy = false } }
                    if !error.isEmpty { Text(error).foregroundStyle(.red) }
                }
                if !answer.isEmpty {
                    Section("Answer") { Text(answer).textSelection(.enabled) }
                }
            }
            .navigationTitle("AutoZen Assistant").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() } } }
        }.onDisappear { task?.cancel() }
    }

    private func ask() {
        busy = true; error = ""
        let input = prompt
        let base = endpoint.trimmingCharacters(in: .whitespacesAndNewlines)
        let selected = model.trimmingCharacters(in: .whitespacesAndNewlines)
        let total = store.accounts.count
        let ready = ServiceName.allCases.map { service in "\(service.title): \(store.accounts.filter { $0.state(for: service).ready }.count)/\(total) marked ready" }.joined(separator: "\n")
        let user = input + (includeStatus ? "\n\nCompletion counts:\n" + ready : "")
        task = Task { @MainActor in
            defer { busy = false }
            do { answer = try await AutoZenAI.ask(endpoint: base, model: selected, prompt: user) }
            catch is CancellationError { }
            catch { if !Task.isCancelled { self.error = error.localizedDescription } }
        }
    }
}

enum AutoZenAI {
    static func ask(endpoint: String, model: String, prompt: String) async throws -> String {
        guard let base = URL(string: endpoint), ["http", "https"].contains(base.scheme ?? ""), base.host != nil, !model.isEmpty else {
            throw NSError(domain: "AutoZenAI", code: 1, userInfo: [NSLocalizedDescriptionKey: "Enter a valid Ollama host and installed model."])
        }
        let url = base.appendingPathComponent("api/chat")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 120
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "model": model, "stream": false,
            "messages": [
                ["role": "system", "content": "You are AutoZen's account setup assistant. Give short practical steps for Gmail, GitHub, MEGA, recovery and session troubleshooting. Never claim you created an account, signed in, verified a code or changed settings. The user completes service forms and verification in the browser. Never request passwords or recovery keys."],
                ["role": "user", "content": prompt]
            ], "options": ["temperature": 0.3]
        ])
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForResource = 120
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw NSError(domain: "AutoZenAI", code: 2, userInfo: [NSLocalizedDescriptionKey: "Ollama request failed. Check the host and model in Ollama."])
        }
        struct Chat: Decodable { struct Message: Decodable { let content: String }; let message: Message }
        let text = try JSONDecoder().decode(Chat.self, from: data).message.content
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw NSError(domain: "AutoZenAI", code: 3, userInfo: [NSLocalizedDescriptionKey: "The model returned an empty answer."])
        }
        return text
    }
}
