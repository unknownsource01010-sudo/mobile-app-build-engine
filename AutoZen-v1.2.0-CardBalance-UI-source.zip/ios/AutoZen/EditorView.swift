import SwiftUI
import UniformTypeIdentifiers

struct EditorView: View {
    @EnvironmentObject var store: AccountStore
    @Environment(\.dismiss) private var dismiss

    @State private var account: AccountRecord
    @State private var password = ""
    @State private var masterPassphrase = ""
    @State private var showImporter = false
    @State private var errorText = ""
    @State private var showError = false

    init(account: AccountRecord? = nil) {
        _account = State(initialValue: account ?? AccountRecord())
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Identity") {
                    TextField("Label", text: $account.label)
                    TextField("Email", text: $account.email)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.emailAddress)
                }

                Section("Encrypted local password") {
                    SecureField(account.secret == nil ? "Password" : "New password (optional)", text: $password)
                    SecureField("Vault passphrase", text: $masterPassphrase)
                    Text("The master passphrase is never saved. Enter it only when storing or revealing a password.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("Recovery") {
                    Button("Choose recovery file") { showImporter = true }
                    if !account.recoveryFileName.isEmpty {
                        Text(account.recoveryFileName).font(.caption)
                    }
                    TextField("Recovery folder / note", text: $account.recoveryFolderNote)
                }

                Section("Notes") {
                    TextEditor(text: $account.notes)
                        .frame(minHeight: 100)
                }
            }
            .navigationTitle(account.label.isEmpty ? "New Identity" : "Edit Identity")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { save() }
                }
            }
            .fileImporter(isPresented: $showImporter, allowedContentTypes: [.item], allowsMultipleSelection: false) { result in
                if case .success(let urls) = result, let first = urls.first {
                    account.recoveryFileName = first.lastPathComponent
                }
            }
            .alert("AutoZen", isPresented: $showError) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(errorText)
            }
        }
    }

    private func save() {
        do {
            if !password.isEmpty {
                guard !masterPassphrase.isEmpty else {
                    errorText = "Enter the vault passphrase before saving a password."
                    showError = true
                    return
                }
                account.secret = try VaultCrypto.encrypt(password, passphrase: masterPassphrase)
            }

            if account.label.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                account.label = account.email.isEmpty ? "Account" : account.email
            }

            store.upsert(account)
            dismiss()
        } catch {
            errorText = error.localizedDescription
            showError = true
        }
    }
}

