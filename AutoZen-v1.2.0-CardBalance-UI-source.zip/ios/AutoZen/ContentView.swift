import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct ContentView: View {
    @EnvironmentObject var store: AccountStore

    @State private var search = ""
    @AppStorage("autozen.private") private var temporary = true
    @State private var editorAccount: AccountRecord?
    @State private var showNewEditor = false
    @State private var browserTarget: BrowserTarget?
    @State private var shareItems: [Any] = []
    @State private var showShare = false
    @State private var revealAccount: AccountRecord?
    @State private var revealPassphrase = ""
    @State private var showReveal = false
    @State private var verificationCode = ""
    @State private var showVerification = false
    @State private var message = ""
    @State private var showMessage = false
    @State private var pendingDelete: AccountRecord?
    @State private var showDelete = false
    @State private var showAssistant = false
    @State private var expanded: Set<UUID> = []
    @State private var showBackupPrompt = false
    @State private var backupPassphrase = ""
    @State private var showRestoreImporter = false
    @State private var restoreData: Data?
    @State private var showRestorePrompt = false
    @State private var serviceEdit: ServiceEditTarget?
    @State private var revealService: ServiceName?
    @State private var inventoryTarget: ServiceEditTarget?

    private var filtered: [AccountRecord] {
        let q = search.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !q.isEmpty else { return store.accounts }
        return store.accounts.filter {
            $0.label.lowercased().contains(q) ||
            $0.email.lowercased().contains(q) ||
            $0.notes.lowercased().contains(q)
        }
    }

    private var selectedAccount: AccountRecord? {
        if let id = expanded.first, let account = filtered.first(where: { $0.id == id }) { return account }
        return filtered.first
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AutoZenTheme.background.ignoresSafeArea()
                VStack(spacing: 12) {
                    dashboardHeader
                    HStack(alignment: .top, spacing: 12) {
                        identityRail.frame(width: 300)
                        if let account = selectedAccount {
                            accountWorkspace(account)
                        } else {
                            AZPanel {
                                ContentUnavailableView("Your account hub", systemImage: "person.crop.circle.badge.plus", description: Text("Add an identity to begin."))
                                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                            }
                        }
                    }
                }.padding(12)
            }
            .navigationBarHidden(true)
            .sheet(isPresented: $showNewEditor) { EditorView().environmentObject(store) }
            .sheet(item: $editorAccount) { EditorView(account: $0).environmentObject(store) }
            .fullScreenCover(item: $browserTarget) { BrowserView(target: $0) }
            .sheet(isPresented: $showAssistant) { AssistantView().environmentObject(store) }
            .sheet(item: $serviceEdit) { ServiceEditor(target: $0).environmentObject(store) }
            .sheet(item: $inventoryTarget) { target in
                NavigationStack { ScrollView { VStack(alignment: .leading, spacing: 12) {
                    if let date = target.account.state(for: target.service).inventoryDate { Text("Saved \(date.formatted())").font(.caption).foregroundStyle(.secondary) }
                    Text(target.account.state(for: target.service).inventory ?? "No contents saved. Open the account, navigate to its listing, and tap Save contents.").textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading)
                }.padding() }.navigationTitle("\(target.service.title) contents").toolbar { Button("Done") { inventoryTarget = nil } } }
            }
            .sheet(isPresented: $showShare) { ActivityView(items: shareItems) }
            .alert("Reveal password", isPresented: $showReveal) { SecureField("Vault passphrase", text: $revealPassphrase); Button("Reveal") { revealPassword() }; Button("Cancel", role: .cancel) {} } message: { Text(revealAccount?.label ?? "Account") }
            .confirmationDialog("Delete identity?", isPresented: $showDelete, titleVisibility: .visible) { Button("Delete", role: .destructive) { if let account = pendingDelete { store.delete(account) } }; Button("Cancel", role: .cancel) {} } message: { Text("This removes the identity and its saved password from AutoZen. It does not delete your online accounts.") }
            .alert("Encrypt backup", isPresented: $showBackupPrompt) { SecureField("Backup passphrase", text: $backupPassphrase); Button("Export") { backupVault() }; Button("Cancel", role: .cancel) {} } message: { Text("Use a separate strong passphrase. Keep it to restore the backup on another device.") }
            .alert("Restore backup", isPresented: $showRestorePrompt) { SecureField("Backup passphrase", text: $backupPassphrase); Button("Restore") { restoreVault() }; Button("Cancel", role: .cancel) { restoreData = nil } } message: { Text("Matching identity IDs are updated; other identities are kept.") }
            .fileImporter(isPresented: $showRestoreImporter, allowedContentTypes: [.json], allowsMultipleSelection: false) { result in do { guard let url = try result.get().first else { return }; let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }; restoreData = try Data(contentsOf: url); backupPassphrase = ""; showRestorePrompt = true } catch { message = error.localizedDescription; showMessage = true } }
            .alert("Verification code", isPresented: $showVerification) { TextField("Code", text: $verificationCode); Button("Copy") { UIPasteboard.general.string = verificationCode }; Button("Cancel", role: .cancel) {} } message: { Text("AutoZen copies the code to the clipboard and does not save it.") }
            .alert("AutoZen", isPresented: $showMessage) { Button("OK", role: .cancel) {} } message: { Text(message) }
        }
    }

    private var dashboardHeader: some View {
        AZPanel { HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 2) { Text("AUTOZEN").font(.title2.bold()); Text("ACCOUNT + FILE HUB").font(.caption2).foregroundStyle(.secondary) }
            TextField("Search identity or email", text: $search).textFieldStyle(.roundedBorder).frame(maxWidth: 330)
            Toggle("Private", isOn: $temporary).toggleStyle(.switch).font(.caption)
            Spacer()
            Text("\(store.accounts.count) identities").font(.caption).foregroundStyle(.secondary)
            Text(AccountSummary.monthlyCost(store.accounts), format: .currency(code: "USD")).font(.caption.bold())
            Button { showAssistant = true } label: { Label("Assistant", systemImage: "sparkles") }.buttonStyle(.bordered)
            Menu { Button("Export CSV") { exportCSV() }; Button("Backup encrypted vault") { backupPassphrase = ""; showBackupPrompt = true }; Button("Restore backup") { showRestoreImporter = true }; Button("Verification code") { verificationCode = ""; showVerification = true } } label: { Image(systemName: "square.and.arrow.up") }.buttonStyle(.bordered)
            Button { showNewEditor = true } label: { Label("Add", systemImage: "plus") }.buttonStyle(.borderedProminent)
        }}
    }

    private var identityRail: some View {
        AZPanel { VStack(alignment: .leading, spacing: 10) {
            Text("IDENTITIES").font(.caption.bold()).foregroundStyle(.secondary)
            ScrollView { LazyVStack(spacing: 8) { ForEach(filtered) { account in
                Button { expanded = [account.id] } label: {
                    HStack { Image(systemName: expanded.contains(account.id) ? "folder.fill" : "folder"); VStack(alignment: .leading) { Text(account.label).font(.subheadline.bold()).lineLimit(1); Text(account.email.isEmpty ? "No email" : account.email).font(.caption2).foregroundStyle(.secondary).lineLimit(1) }; Spacer(); Text("\(ServiceName.allCases.filter { account.state(for: $0).ready }.count)/\(ServiceName.allCases.count)").font(.caption2).monospacedDigit() }
                    .padding(10).background(expanded.contains(account.id) ? AutoZenTheme.accent.opacity(0.14) : AutoZenTheme.inset, in: RoundedRectangle(cornerRadius: 12))
                }.buttonStyle(.plain)
            } } }
        }}
    }

    private func accountWorkspace(_ account: AccountRecord) -> some View {
        AZPanel { VStack(alignment: .leading, spacing: 12) {
            HStack { VStack(alignment: .leading) { Text(account.label).font(.title3.bold()); Text(account.email).font(.caption).foregroundStyle(.secondary) }; Spacer(); Button("Edit") { editorAccount = account }.buttonStyle(.bordered); Menu { Button("Reveal identity password") { revealAccount = account; revealService = nil; revealPassphrase = ""; showReveal = true }; Button("Delete", role: .destructive) { pendingDelete = account; showDelete = true } } label: { Image(systemName: "ellipsis.circle") }.buttonStyle(.bordered) }
            HStack { Label(account.recoveryFileName.isEmpty ? "No recovery file" : account.recoveryFileName, systemImage: "key.horizontal").font(.caption); Spacer(); Button("Next setup step") { if let service = ServiceName.allCases.first(where: { !account.state(for: $0).ready }) { open(account, service, account.state(for: service).lastOpen == nil ? .create : .login) } else { message = "All services are marked ready. Review recovery details and export a backup."; showMessage = true } }.buttonStyle(.borderedProminent) }
            Divider()
            ScrollView { LazyVStack(spacing: 10) { ForEach(ServiceName.allCases) { service in serviceCard(account, service) } } }
        }.frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top) }
    }

    private func serviceCard(_ account: AccountRecord, _ service: ServiceName) -> some View {
        let state = account.state(for: service)
        return HStack(spacing: 12) {
            Image(systemName: state.ready ? "checkmark.circle.fill" : "circle").foregroundStyle(state.ready ? .green : .secondary).font(.title3)
            VStack(alignment: .leading, spacing: 3) { Text(service.title).font(.headline); Text(state.username ?? account.email).font(.caption).foregroundStyle(.secondary).lineLimit(1) }.frame(width: 170, alignment: .leading)
            VStack(alignment: .leading) { Text(state.amount.map { String(format: "$%.2f", $0) } ?? "Cost unknown").font(.caption.bold()); Text(state.billing ?? "No billing cycle").font(.caption2).foregroundStyle(.secondary) }.frame(width: 120, alignment: .leading)
            Button { inventoryTarget = ServiceEditTarget(account: account, service: service) } label: { VStack(alignment: .leading) { Text("CONTENTS").font(.caption2.bold()); Text(state.inventory?.isEmpty == false ? state.inventory! : "Not scanned").font(.caption).lineLimit(1) } }.buttonStyle(.plain).frame(maxWidth: .infinity, alignment: .leading)
            Button("Open") { open(account, service, .login) }.buttonStyle(.borderedProminent)
            Button { store.toggleReady(accountID: account.id, service: service) } label: { Image(systemName: "checkmark") }.buttonStyle(.bordered)
            Menu { Button("Edit service") { serviceEdit = ServiceEditTarget(account: account, service: service) }; Button("Create account") { open(account, service, .create) }; Button("Copy username") { UIPasteboard.general.string = state.username ?? account.email }; Button("View saved contents") { inventoryTarget = ServiceEditTarget(account: account, service: service) }; Button("Copy password") { revealAccount = account; revealService = service; revealPassphrase = ""; showReveal = true } } label: { Image(systemName: "ellipsis") }.buttonStyle(.bordered)
        }.padding(12).background(AutoZenTheme.inset, in: RoundedRectangle(cornerRadius: 14))
    }

    private func open(_ account: AccountRecord, _ service: ServiceName, _ mode: BrowserMode) {
        store.markOpened(accountID: account.id, service: service)
        browserTarget = BrowserTarget(
            accountID: account.id,
            accountLabel: account.label,
            service: service,
            url: mode == .create ? service.createURL : service.loginURL,
            temporary: temporary
        )
    }

    private func revealPassword() {
        guard let account = revealAccount else { return }
        guard let payload = revealService.flatMap({ account.state(for: $0).secret }) ?? account.secret else {
            message = "No password is stored for this identity."
            showMessage = true
            return
        }

        do {
            let password = try VaultCrypto.decrypt(payload, passphrase: revealPassphrase)
            UIPasteboard.general.setItems([["public.utf8-plain-text": password]], options: [.localOnly: true, .expirationDate: Date().addingTimeInterval(60)])
            revealPassphrase = ""
            message = "Password decrypted and copied to the clipboard."
            showMessage = true
        } catch {
            message = "Vault passphrase is incorrect or the vault data could not be opened."
            showMessage = true
        }
    }

    private func exportCSV() {
        do {
            shareItems = [try store.csvURL()]
            showShare = true
        } catch {
            message = error.localizedDescription
            showMessage = true
        }
    }

    private func backupVault() {
        do {
            shareItems = [try store.backupURL(passphrase: backupPassphrase)]
            backupPassphrase = ""
            showShare = true
        } catch {
            message = error.localizedDescription
            showMessage = true
        }
    }

    private func restoreVault() {
        do {
            guard let data = restoreData else { return }
            try store.restore(data, passphrase: backupPassphrase)
            restoreData = nil; backupPassphrase = ""
            message = "Backup restored."; showMessage = true
        } catch { message = error.localizedDescription; showMessage = true }
    }
}

enum BrowserMode { case login, create }

struct ServiceRow: View {
    let account: AccountRecord
    let service: ServiceName
    let temporary: Bool
    let open: (BrowserMode) -> Void
    let toggleReady: () -> Void

    var body: some View {
        HStack(spacing: 10) {
            Circle()
                .fill(account.state(for: service).ready ? Color.green : Color.secondary.opacity(0.4))
                .frame(width: 8, height: 8)

            Text(service.title)
                .frame(width: 58, alignment: .leading)

            Spacer()

            Button("Create") { open(.create) }
                .buttonStyle(.bordered)

            Button("Login") { open(.login) }
                .buttonStyle(.borderedProminent)

            Button {
                toggleReady()
            } label: {
                Image(systemName: account.state(for: service).ready ? "checkmark.circle.fill" : "circle")
            }
            .buttonStyle(.plain)
        }
        .font(.caption)
    }
}

struct ActivityView: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
