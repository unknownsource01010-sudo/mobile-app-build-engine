import SwiftUI
import WebKit
import CryptoKit
import SafariServices

struct BrowserTarget: Identifiable {
    let id = UUID()
    let accountID: UUID
    let accountLabel: String
    let service: ServiceName
    let url: URL
    let temporary: Bool
}

struct BrowserView: View {
    let target: BrowserTarget
    @EnvironmentObject var store: AccountStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var controls = BrowserControls()
    @State private var showExternal = false
    @State private var confirmExternal = false

    var body: some View {
        NavigationStack {
            IsolatedWebView(target: target, controls: controls, onFinish: refreshSavedListing)
                .ignoresSafeArea(edges: .bottom)
                .overlay(alignment: .bottom) {
                    if !controls.error.isEmpty {
                        Text(controls.error).font(.caption).padding().background(.regularMaterial).onTapGesture { controls.error = "" }
                    }
                }
                .navigationTitle("\(target.accountLabel) · \(target.service.title)")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .topBarLeading) {
                        Button("Done") { dismiss() }
                    }
                    ToolbarItemGroup(placement: .bottomBar) {
                        Button { controls.webView?.goBack() } label: { Image(systemName: "chevron.left") }.disabled(!controls.canBack)
                        Button { controls.webView?.goForward() } label: { Image(systemName: "chevron.right") }.disabled(!controls.canForward)
                        Spacer()
                        if controls.loading { ProgressView() }
                        Button { controls.webView?.reload() } label: { Image(systemName: "arrow.clockwise") }
                        Button("Save contents") { captureContents() }
                        Button("Safari") { confirmExternal = true }
                    }
                }
                .sheet(isPresented: $showExternal) { ExternalBrowser(url: controls.webView?.url ?? target.url) }
                .confirmationDialog("Open outside this profile?", isPresented: $confirmExternal, titleVisibility: .visible) {
                    Button("Open Safari") { showExternal = true }
                    Button("Cancel", role: .cancel) {}
                } message: { Text("Safari uses its own session. It is outside AutoZen's separate identity cookie store. Use it only if the service blocks embedded sign-in.") }
        }
    }

    private func captureContents() {
        guard let web = controls.webView else { return }
        web.evaluateJavaScript("JSON.stringify({title:document.title,url:location.href,text:document.body.innerText.slice(0,16000)})") { value, error in
            if let error { controls.error = error.localizedDescription; return }
            guard let json = value as? String, let data = json.data(using: .utf8),
                  let page = try? JSONDecoder().decode(PageContents.self, from: data),
                  var account = store.accounts.first(where: { $0.id == target.accountID }) else { return }
            var state = account.state(for: target.service)
            state.inventory = "\(page.title)\n\(page.url)\n\n\(page.text)"
            state.inventoryDate = Date()
            state.inventoryURL = page.url
            account.services[target.service.rawValue] = state
            store.upsert(account)
            controls.error = "Visible page contents saved."
        }
    }

    private func refreshSavedListing() {
        guard let account = store.accounts.first(where: { $0.id == target.accountID }),
              let saved = account.state(for: target.service).inventoryURL,
              controls.webView?.url?.absoluteString == saved else { return }
        captureContents()
    }
}

struct PageContents: Decodable { let title: String; let url: String; let text: String }

final class BrowserControls: ObservableObject {
    weak var webView: WKWebView?
    @Published var canBack = false
    @Published var canForward = false
    @Published var loading = false
    @Published var error = ""
}

struct ExternalBrowser: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> SFSafariViewController { SFSafariViewController(url: url) }
    func updateUIViewController(_ controller: SFSafariViewController, context: Context) {}
}

struct IsolatedWebView: UIViewRepresentable {
    let target: BrowserTarget
    let controls: BrowserControls
    let onFinish: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(controls: controls, onFinish: onFinish) }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()

        if target.temporary {
            config.websiteDataStore = .nonPersistent()
        } else {
            config.websiteDataStore = WKWebsiteDataStore(forIdentifier: persistentStoreID())
        }

        config.preferences.javaScriptCanOpenWindowsAutomatically = true

        let view = WKWebView(frame: .zero, configuration: config)
        view.navigationDelegate = context.coordinator
        view.uiDelegate = context.coordinator
        view.allowsBackForwardNavigationGestures = true
        controls.webView = view
        view.load(URLRequest(url: target.url))
        return view
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    private func persistentStoreID() -> UUID {
        let text = "\(target.accountID.uuidString.lowercased())|\(target.service.rawValue)"
        let input = Data(text.utf8)
        let digest = SHA256.hash(data: input)
        let bytes = Array(digest)
        let hexParts = bytes.map { byte -> String in
            String(format: "%02x", byte)
        }
        let hex = hexParts.joined()
        let raw = String(hex.prefix(32))

        let p1 = String(raw.prefix(8))
        let p2Start = raw.index(raw.startIndex, offsetBy: 8)
        let p2End = raw.index(p2Start, offsetBy: 4)
        let p2 = String(raw[p2Start..<p2End])

        let p3Start = p2End
        let p3End = raw.index(p3Start, offsetBy: 4)
        let p3 = String(raw[p3Start..<p3End])

        let p4Start = p3End
        let p4End = raw.index(p4Start, offsetBy: 4)
        let p4 = String(raw[p4Start..<p4End])

        let p5 = String(raw[p4End...])
        let value = "\(p1)-\(p2)-\(p3)-\(p4)-\(p5)"
        return UUID(uuidString: value) ?? UUID()
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        let controls: BrowserControls
        let onFinish: () -> Void
        init(controls: BrowserControls, onFinish: @escaping () -> Void) { self.controls = controls; self.onFinish = onFinish }
        private func sync(_ webView: WKWebView) {
            controls.canBack = webView.canGoBack; controls.canForward = webView.canGoForward
        }
        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) { controls.loading = true; controls.error = ""; sync(webView) }
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            controls.loading = false; sync(webView)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [weak self] in self?.onFinish() }
        }
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { controls.loading = false; controls.error = error.localizedDescription; sync(webView) }
        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { controls.loading = false; controls.error = error.localizedDescription; sync(webView) }
        func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
            present(message, actions: [UIAlertAction(title: "OK", style: .default) { _ in completionHandler() }], fallback: completionHandler)
        }
        func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
            present(message, actions: [UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(false) }, UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) }], fallback: { completionHandler(false) })
        }
        private func present(_ text: String, actions: [UIAlertAction], fallback: () -> Void) {
            let root = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.flatMap(\.windows).first { $0.isKeyWindow }?.rootViewController
            var top = root
            while let next = top?.presentedViewController { top = next }
            guard let top else { fallback(); return }
            let alert = UIAlertController(title: "AutoZen Browser", message: text, preferredStyle: .alert)
            actions.forEach { alert.addAction($0) }; top.present(alert, animated: true)
        }

        func webView(
            _ webView: WKWebView,
            createWebViewWith configuration: WKWebViewConfiguration,
            for navigationAction: WKNavigationAction,
            windowFeatures: WKWindowFeatures
        ) -> WKWebView? {
            if navigationAction.targetFrame == nil, let url = navigationAction.request.url {
                webView.load(URLRequest(url: url))
            }
            return nil
        }
    }
}
