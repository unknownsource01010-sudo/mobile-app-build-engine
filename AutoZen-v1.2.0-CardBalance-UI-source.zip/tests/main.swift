import Foundation

func check(_ condition: Bool, _ name: String) {
    guard condition else { fatalError("FAIL: " + name) }
    print("PASS: " + name)
}
let payload = try VaultCrypto.encrypt("a-secret-test-password", passphrase: "a-long-test-passphrase")
let clear = try VaultCrypto.decrypt(payload, passphrase: "a-long-test-passphrase")
check(clear == "a-secret-test-password", "vault encryption round trip")
do {
    _ = try VaultCrypto.decrypt(payload, passphrase: "wrong")
    fatalError("Wrong passphrase accepted")
} catch { print("PASS: wrong passphrase rejected") }
var account = AccountRecord()
account.label = "Test"
account.services["github"] = ServiceState(ready: true, username: "test-user", amount: 24, billing: "yearly")
account.services["mega"] = ServiceState(amount: 3, billing: "monthly", secret: payload)
let encoded = try JSONEncoder().encode([account])
let decoded = try JSONDecoder().decode([AccountRecord].self, from: encoded)
check(decoded == [account], "all service fields round trip")
check(AccountSummary.monthlyCost(decoded) == 5, "monthly plus annual normalized cost")
let oldState = try JSONDecoder().decode(ServiceState.self, from: Data("{\"ready\":false}".utf8))
check(oldState.username == nil && oldState.secret == nil, "legacy service state loads")
let backup = try VaultCrypto.encrypt(String(decoding: encoded, as: UTF8.self), passphrase: "backup-test-password")
let recovered = try VaultCrypto.decrypt(backup, passphrase: "backup-test-password")
check(try JSONDecoder().decode([AccountRecord].self, from: Data(recovered.utf8)) == decoded, "portable encrypted backup round trip")
