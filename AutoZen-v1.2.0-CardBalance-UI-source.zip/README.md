# AutoZen 1.1.0

Native iOS account hub with expandable identity/service rows. Portrait and landscape are supported. Expand an identity for Gmail, GitHub and MEGA. Swipe the table horizontally for username, USD amount/billing, next date, saved contents and Open actions. Use the row menu to edit details, create the account or copy saved credentials. Known monthly costs normalize annual amounts and exclude unknown/one-time costs.

## Automation and contents
Next setup step opens the first unfinished service and remembers when it was opened. Complete the service's sign-in/verification, then mark ready. Account creation, verification, billing and readiness are not fabricated or silently inferred. From an account listing, Save contents captures its current page title, URL and visible text (up to 16,000 characters), dated under that service. Returning to the same saved listing refreshes that snapshot after navigation completes. Tap Save contents again after in-page folder changes. This is a visible-page snapshot, not a recursive inventory or live synchronization of an entire account. Edit contents manually when needed. CSV exports one row per service with costs, dates and saved contents; it excludes password ciphertext and plaintext.

## Separate identities
Temporary/private mode is on by default and discards browser cookies on close. When disabled, a deterministic separate persistent WebKit store is used for each identity/service. Sites can still correlate accounts using their own records, your IP or sign-in details. Safari fallback requires explicit confirmation because its browser session is outside this isolation. Some sites block embedded sign-in and require that fallback.

## Passwords and backup
Save usernames and passwords in Service details. Passwords use the existing AES-GCM vault format, preserving legacy data compatibility; your passphrase is never stored. Copy password expires from the local clipboard after 60 seconds. New portable backups encrypt the whole account database using a separate passphrase of at least 12 characters. Restore merges IDs without deleting other identities and also accepts legacy backups. Keep your individual vault passphrase to open saved passwords after restoring. Browser cookies are not included in the backup. Account labels/notes are locally stored with iOS file protection; don't put recovery secrets in notes or visible-content snapshots. Chrome's password database is not written by this app.

## Assistant
The offline checklist works on the phone. Optional local AI connects directly to your chosen Ollama host (default model llama3.2:3b, editable). Only the typed prompt and optional service completion counts are sent. Model weights run on that host and are not inside the IPA.

## Build
Upload this source folder's contents to a repository. .github/workflows/build-ios.yml performs crypto/model regression checks and builds an unsigned device IPA. It must be signed before installation. Vault round-trip, wrong passphrase rejection, legacy service decoding, service fields, normalized cost and portable encrypted backup are tested on macOS. Physical-device sign-in and live Ollama responses are not tested in this environment.
